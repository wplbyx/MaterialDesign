//获取所有知识分类
function getClassify() {
    $.ajax({
        url: urlList.getClassifyList,
        type: "post",
        async: false,
        dataType: "json",
        success: function (data) {
            classifyJSON = data;
            classifySelector("selectZy", "selector");
            $("#selectZy").select2({
                placeholder: "全部",
                allowClear: true
            });
        }
    });
}

//获取专业等级
function getSpecialtyLevelList() {
    $.ajax({
        url: urlList.getSpecialtyLevelList,
        type: "post",
        async: false,
        dataType: "json",
        success: function (data) {
            specialtyLevelJSON = data;
            var selectZyLevelHtml = specialtyLevelSelector("selector");
            $("#selectZyLevel").html(selectZyLevelHtml);
        }
    });
}

function getSpecialtyList() {
    $.ajax({
        url: urlList.getSpecialtyList,
        type: "post",
        async: false,
        dataType: "json",
        success: function (data) {
            specialtyJSON = data;
            specialtySelector("selectZy", "selector");
            $("#selectZy").select2({
                placeholder: "全部",
                allowClear: true
            });
//			getSpecialtyOne(data);
        }
    });
}

function getSpecialtyOne(data) {
    var html = "<a href='javascript:void(0)' class='file-control active' onclick='changeSpecialty(this,0)'>全部</a>";
    var spanDis = false;
    for (var i = 0; i < data.length; i++) {
        if (i == 9) {
            html += "<span style='display: none;' id='manyId'>";
            spanDis = true;
        }
        html += "<a href='javascript:void(0)' class='file-control' onclick='changeSpecialty(this," + data[i].id + ")'>" + data[i].name + "</a>";
    }
    if (spanDis) {
        html += "</span>";
        html += "<a href='javascript:void(0)' class='f12' onclick='showMany(this)'>显示更多</a>";
    }
    $("#selectZy").html(html);
}

function showMany(dom) {
    var aHtml = dom.innerHTML;
    if (aHtml == "显示更多") {
        $(dom).text('收起更多');
        $("#manyId").css("display", "");
    } else {
        $(dom).text('显示更多');
        $("#manyId").css("display", "none");
    }
}

function changeSpecialty(dom, id) {
    $(dom).parent().find("a").removeClass("active");
    $(dom).addClass("active");
    if (id == 0) {
        selectZy = "";
    } else {
        selectZy = id;
    }
    getViewTable();
}

function changeUser(dom, id) {
    $(dom).parent().find("a").removeClass("active");
    $(dom).addClass("active");
    if (id == 0) {
        selectEnd = "全部用户";
    } else if (id == 1) {
        selectEnd = "未过期用户";
    } else if (id == 2) {
        selectEnd = "已过期用户";
    }
    getViewTable();
}

function zyISShow(type) {
    var err = true;
    if (type == "add") {
        var _opt = $("#addUserform").find(".opt");
        var ids = "@";
        for (var i = 0; i < _opt.length; i++) {
            if (ids.indexOf("@" + $("#add_form_select" + (i + 1)).val() + "@") > -1) {
                $("#spanTitle" + (i + 1)).html("专业不能重复选择哦！");
                $("#spanTitle" + (i + 1)).show();
                err = false;
            } else {
                $("#spanTitle" + (i + 1)).html("");
                $("#spanTitle" + (i + 1)).hide();
            }
            ids += $("#add_form_select" + (i + 1)).val() + "@";
        }
    } else {
        var _opt = $("#updateUserform").find(".opt");
        var ids = "@";
        for (var i = 0; i < _opt.length; i++) {
            if (ids.indexOf("@" + $("#update_form_select" + (i + 1)).val() + "@") > -1) {
                $("#update_spanTitle" + (i + 1)).html("专业不能重复选择哦！");
                $("#update_spanTitle" + (i + 1)).show();
                err = false;
            } else {
                $("#update_spanTitle" + (i + 1)).html("");
                $("#update_spanTitle" + (i + 1)).hide();
            }
            ids += $("#update_form_select" + (i + 1)).val() + "@";
        }
    }
    return err;
}

//获取专业等级
function getLevelList(selectId, number) {
    var selectZyId = "selectZy";
    var levelId = "selectZyLevel";
    var _classifyLevel = "@";
    if (selectId == 0) {
        levelId = "selectZyLevel";
        selectZyId = "selectZy";
        $("#selectZyLevel").val("");
        $("#selectZyLevel").select2({
            placeholder: "全部",
            allowClear: true
        });
    } else if (selectId == 1) {
        levelId = "specLevel" + number;
        selectZyId = "add_form_select" + number;
        zyISShow("add");
    } else if (selectId == 2) {
        levelId = "update_specLevel" + number;
        selectZyId = "update_form_select" + number;
        zyISShow("update");
    }
    var selectZy = $("#" + selectZyId).val();
    var html = "<option  value=''>全部</option>";
    $("#" + levelId).html(html);
    if (selectZy != "") {
        $.ajax({
            url: urlList.queryLevelList,
            type: "post",
            async: false,
            data: {
                "specialtyId": selectZy
            },
            dataType: "json",
            success: function (data) {
                levelJSON = data;
                var html = "<option  value=''>全部</option>";
                if (data != null && data.length > 0) {
                    for (var i = 0; i < data.length; i++) {
                        html = html + "<option  value='" + data[i].id + "'>" + data[i].name + "</option>";
                    }
                }
                $("#" + levelId).html(html);
            }
        });
    }
}


function taskCount() {
    $.ajax({
        url: urlList.queryTaskCount,
        type: "post",
        dataType: "json",
        success: function (data) {
            if (data.res == 1) {
                window.location.href = urlList.importCompanyUserPage;
            } else {
                $.alert({
                    title: "警告！",
                    message: "系统服务繁忙，暂不予以处理哦！",
                    type: "warning",
                    ok: function () {
                    }
                });
            }
        }
    });
}

function deleteDepInfo() {
    $.ajax({
        type: "post",
        url: urlList.findDepIdIsUse,
        data: {
            depId: depId,
        },
        async: false,
        dataType: "json",
        success: function (data) {
            if (data != null && data != undefined && data != 'null' && data != 'undefined' && data != '') {
                if (data > 0) {
                    $.confirm({
                        title: "删除部门",
                        type: "warning",
                        message: "当前部门已经关联了邀请码,删除后邀请码将会失效,请确认。",
                        ok: function (modal) {
                            $.ajax({
                                type: "post",
                                async: false,
                                url: urlList.deleteDepInfo,
                                data: {
                                    depId: depId,
                                    status: "3"
                                },
                                success: function (data) {
                                    if (data > 0) {
                                        depCode = $("[data-id=" + depCode + "]").attr("data-parent-id");
                                        getDepInfo();
                                        $("#bianjibumenmodal").modal("hide");
                                    } else {
                                        $.alert({
                                            title: "警告！",
                                            message: "删除部门失败！",
                                            type: "warning",
                                            ok: function () {
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    });
                } else {
                    $.confirm({
                        title: "删除部门",
                        type: "warning",
                        message: "确定要删除" + depName + "部门？删除后部门下的员工不会一起删除。",
                        ok: function (modal) {
                            $.ajax({
                                type: "post",
                                async: false,
                                url: urlList.deleteDepInfo,
                                data: {
                                    depId: depId
                                },
                                success: function (data) {
                                    if (data > 0) {
                                        depCode = $("[data-id=" + depCode + "]").attr("data-parent-id");
                                        getDepInfo();
                                        $("#bianjibumenmodal").modal("hide");
                                    } else {
                                        $.alert({
                                            title: "警告！",
                                            message: "删除部门失败！",
                                            type: "warning",
                                            ok: function () {
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    });
                }
            } else {
                $.confirm({
                    title: "删除部门",
                    type: "warning",
                    message: "确定要删除" + depName + "部门？删除后部门下的员工不会一起删除。",
                    ok: function (modal) {
                        $.ajax({
                            type: "post",
                            async: false,
                            url: urlList.deleteDepInfo,
                            data: {
                                depId: depId
                            },
                            success: function (data) {
                                if (data > 0) {
                                    depCode = $("[data-id=" + depCode + "]").attr("data-parent-id");
                                    getDepInfo();
                                    $("#bianjibumenmodal").modal("hide");
                                } else {
                                    $.alert({
                                        title: "警告！",
                                        message: "删除部门失败！",
                                        type: "warning",
                                        ok: function () {
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
            }
        }
    });


}

function toupdate(id, event) {
    event.stopPropagation();
    $('#updateuserInfo').find("input").val("");
    $('#updateuserInfo').find("textarea").val("");
    $("#updateUserform").find(".opt").remove();
    $("#updateTeacherBox").parent().removeClass("checked");
    $('#updateuserInfo .i-checks').iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-green',
    });
    $('#updateuserInfo').find(".has-error").find(".cuowutishi").text("");
    $('#updateuserInfo').find(".has-error").removeClass("has-error");
    $("#updateTeacherBox").removeAttr('checked');
    $("#updateTeacherBox").iCheck('update');

    $('#updateuserInfo').modal("show", {keyboard: false});
    $.ajax({
        type: "post",
        async: false,
        url: urlList.selectUser,
        data: {"id": id},
        success: function (data) {
            if (data == null) {
                return;
            }
            getId = id;
            data = eval("(" + data + ")");
            var duser = data.res;
            if (duser == null || duser.length == 0) {
                return;
            }
            $("#editUserName").val(emp3(duser.username));
            $("#editTel").val(emp3(duser.phonenumber));
            if (duser.admin == 1) {
                $("#editTel").attr("readonly", "readonly");
                //如果当前操作人是超级管理员可以修改姓名
                if (isCompanyManager == "false") {
                    $("#editUserName").attr("readonly", "readonly");
                }
            } else {
                $("#editTel").removeAttr("readonly");
                $("#editUserName").removeAttr("readonly");
            }

            if (duser.identity != null && duser.identity == "|001|") {
                $("#updateTeacherBox").prop('checked', 'checked');
                $("#updateTeacherBox").iCheck('update');
            }
            if (duser.sex == "女") {
                $("#upsex1").parent().removeClass("checked");
                $("#upsex2").parent().addClass("checked");
                $("#upsex1").removeAttr("checked");
                $("#upsex2").attr("checked", "true");
            } else {
                $("#upsex1").parent().addClass("checked");
                $("#upsex2").parent().removeClass("checked");
                $("#upsex1").attr("checked", "true");
                $("#upsex2").removeAttr("checked");
            }
            $("#updateEmail").val(duser.email == "null" ? "" : duser.email);
            initSpeciatyLevel(duser.specLevels, "dv_up_classifyLevel", "updateUserform");
            $("#updateCc").val(emp3(duser.goodField));
            $("#updateBeif").val(emp3(duser.teacherBrief));
            $("#updateDepId").val(emp1(duser.depName));
            $("#updatePosition").val(emp3(duser.position));
            if (duser.jobNumber == null || duser.jobNumber == "null") {
                $("#updateJobNumber").val("");
            } else {
                $("#updateJobNumber").val(emp1(duser.jobNumber));
            }
            if (duser.workYear == null || duser.workYear == "null") {
                $("#updateWorkYear").val("");
            } else {
                $("#updateWorkYear").val(emp1(duser.workYear));
            }
            updateTreeObj = $.fn.zTree.getZTreeObj("zTree_updateDepId");//获取ztreeObject对象
            if (updateTreeObj != null) {
                updateTreeObj.expandAll(false);
                updateTreeObj.checkAllNodes(false);
                if (duser.depList != null && duser.depList != "") {
                    if (isDepMany == 'true') {
                        var depNames = "";
                        var depIds = "";
                        for (var i = 0; i < duser.depList.length; i++) {
                            var selectNode = updateTreeObj.getNodeByParam("code", duser.depList[i].id);
                            updateTreeObj.checkNode(selectNode, true, true);
                            updateTreeObj.selectNode(selectNode, false);
                            if (i != 0) {
                                depNames += ",";
                                depIds += ",";
                            }
                            depNames += duser.depList[i].depName;
                            depIds += duser.depList[i].id;
                        }
                        if (depIds != "") {
                            GroupSelector.setValue($("#updateDepId"), depIds, depNames);
                        }
                    } else {
                        var selectNode = updateTreeObj.getNodeByParam("code", duser.depId);
                        updateTreeObj.checkNode(selectNode, true, true);
                        updateTreeObj.selectNode(selectNode, false);
                        GroupSelector.setValue($("#updateDepId"), duser.depId, emp1(duser.depName));
                    }
                }
            }
        }
    });
}

// 修用户信息
function updateUser() {
    $.ajax({
        type: 'post',
        url: urlList.selectByTel,
        data: {
            "tel": $("#editTel").val(),
            "id": getId
        },
        success: function (data) {
            if (data * 1 == 0) {
                var userName = $("#editUserName").val();
                if ($.trim(userName).length == 0) {
                    showValidated($("#editUserName"), "姓名不能为空", "has-error");
                    return;
                } else {
                    hideValidated($("#editUserName"));
                }
                if ($.trim(userName).length < 2) {
                    showValidated($("#editUserName"), "姓名不能小于2个字符", "has-error");
                    return;
                } else {
                    hideValidated($("#editUserName"));
                }
                //邮箱验证
                if (EMAIL_IS_REQUIRED && $.trim($("#updateEmail").val()).length == 0) {
                    showValidated($("#updateEmail"), "邮箱不能为空", "has-error");
                    return;
                } else {
                    hideValidated($("#updateEmail"));
                }
                var regexString = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
                //邮箱正则验证
                if (($.trim($("#updateEmail").val()).length > 0 || EMAIL_IS_REQUIRED) && !(regexString.test($.trim($("#updateEmail").val())))) {
                    showValidated($("#updateEmail"), "邮箱格式不正确", "has-error");
                    return;
                } else {
                    hideValidated($("#updateEmail"));
                }
                //工号验证
                if (JOBNUMBER_IS_REQUIRED && $.trim($("#updateJobNumber").val()).length == 0) {
                    showValidated($("#updateJobNumber"), "工号不能为空", "has-error");
                    return;
                } else {
                    hideValidated($("#updateJobNumber"));
                }
                //手机号验证
                if ($.trim($("#editTel").val()).length == 0) {
                    showValidated($("#editTel"), "手机号不能为空", "has-error");
                    return;
                } else {
                    hideValidated($("#editTel"));
                }
                regexString = /^(1[0-9])\d{9}$/;
                //手机号正则验证
                if (!(regexString.test($.trim($("#editTel").val())))) {
                    showValidated($("#editTel"), "手机号格式不正确", "has-error");
                    return;
                } else {
                    hideValidated($("#editTel"));
                }
                if ($.trim($("#updateCc").val()).length > 64) {
                    return false;
                }
                if ($.trim($("#updateBeif").val()).length > 1024) {
                    return false;
                }
                var upSex = "";
                if ($("#upsex1").parent().hasClass("checked")) {
                    upSex = "男";
                } else {
                    upSex = "女";
                }
                if ($("#updateWorkYear").val() > 100 || $("#updateWorkYear").val() < 0) {
                    showValidated($("#updateWorkYear"), "您输入的工作年限有误", "has-error");
                    return;
                } else {
                    hideValidated($("#updateWorkYear"));
                }
                var _classifyLevel = getClassifyLevelParams("updateUserform");
                if (_classifyLevel.noFillCount > 0) {
                    return;
                } else {
                    var err = zyISShow("update");
                    if (err) {
                        updateUserInfo(upSex, _classifyLevel.calssifyLevel.join(","));
                    }
                }
            } else {
                $.alert({
                    title: "提示！",
                    message: "手机号码已存在",
                    type: "warning",
                    ok: function (modal) {
                    }
                });
            }
        }
    });
}

function updateUserInfo(upSex, calssifyLevel) {
    //姓名验证
    var userName = $("#editUserName").val();
    if ($.trim(userName).length == 0) {
        showValidated($("#editUserName"), "姓名不能为空", "has-error");
        return;
    } else {
        hideValidated($("#editUserName"));
    }
    if ($.trim(userName).length < 2) {
        showValidated($("#editUserName"), "姓名不能小于2个字符", "has-error");
        return;
    } else {
        hideValidated($("#editUserName"));
    }
    //邮箱验证
    if (EMAIL_IS_REQUIRED && $.trim($("#updateEmail").val()).length == 0) {
        showValidated($("#updateEmail"), "邮箱不能为空", "has-error");
        return;
    } else {
        hideValidated($("#updateEmail"));
    }
    //工号验证
    if (JOBNUMBER_IS_REQUIRED && $.trim($("#updateJobNumber").val()).length == 0) {
        showValidated($("#updateJobNumber"), "工号不能为空", "has-error");
        return;
    } else {
        hideValidated($("#updateJobNumber"));
    }
    //手机号验证
    var phone = $("#editTel").val();
    if ($.trim($("#editTel").val()).length == 0) {
        showValidated($("#editTel"), "手机号不能为空", "has-error");
        return;
    } else {
        hideValidated($("#editTel"));
    }
    var identity = "";
    if ($("#updateTeacherBox").parent().hasClass("checked")) {
        identity = "|001|";
    }
    var dep = "";
    if ($("#updateDepId").val() != null) {
        if ($("#updateDepId").val().indexOf("请选择") > -1) {
            $("#updateDepId").val($("#updateDepId").val().substring(4));
        }
        dep = $("#updateDepId").val();
    }
    $.ajax({
        type: 'post',
        url: urlList.updateUser,
        data: {
            "username": $("#editUserName").val(),
            "tel": $("#editTel").val(),
            "usersex": upSex,
            "identity": identity,
            "email": $("#updateEmail").val(),
            'jobNumber': $("#updateJobNumber").val(),
            "calssifyLevel": calssifyLevel,
            "path": path1,
            "dateTag": dateTag,
            "good": $("#updateCc").val(),
            "beif": $("#updateBeif").val(),
            "id": getId,
            'dep': dep,
            "workYear": $("#updateWorkYear").val(),
            "position": $("#updatePosition").val()
        },
        success: function (data) {
            if (data == "success") {
                // getViewTable();
                if (isDep == "true") {
                    getDepInfo();
                } else {
                    getViewTable();
                }
                $('#updateuserInfo').modal("hide");
                if (current_user_id == getId) {
                    $('#current_user_name').html($("#editUserName").val());
                }
            } else if (data == "exsitJobNumber") {
                $.alert({
                    title: "提示！",
                    message: "人员工号已存在哦!",
                    type: "warning",
                    ok: function (modal) {
                    }
                });
            } else {
                $.alert({
                    title: "提示！",
                    message: "修改失败",
                    type: "warning",
                    ok: function (modal) {
                    }
                });
            }
        }
    });
}

function del(id, event) {
    event.stopPropagation();
    $.confirm({
        title: "删除用户",
        message: "用户删除后不可恢复，确定删除吗？",
        type: "warning",
        ok: function (modal) {
            $.ajax({
                type: 'post',
                url: urlList.delUsers,
                data: {
                    'uids': id + ","
                },
                datatype: 'json',
                success: function (obj) {
                    var obj = eval("(" + obj + ")");
                    if (obj["res"] == 1) {
                        // getViewTable();
                        if (isDep == "true") {
                            getDepInfo();
                        } else {
                            getViewTable();
                        }
                    }
                }
            });
        }, cancel: function (modal) {
        }
    });
}

function emp(val) {
    return val == null || "null" == val ? "&nbsp;&nbsp;" : val;
}

function emp1(val) {
    return val == null || "null" == val ? "请选择" : val;
}

function emp3(val) {
    return val == null || "null" == val ? "" : val;
}

/**
 * 显示错误信息
 */
function showValidated(group, msg, css) {
    if (css == '') {
        group.parent().parent().removeClass("has-error");
        group.parent().find("span").text(msg).attr("style", "color:green").show();
    } else {
        group.parent().parent().addClass("has-error");
        group.parent().find("span").text(msg).attr("style", "color:red").show();
    }
}

/**
 * 去除错误信息
 */
function hideValidated(group) {
    group.parent().parent().removeClass("has-error");
    group.parent().find("span").hide();
}

//检查是否可以继续添加人员
function saveUserBefore() {
    var result = 1;
    $.ajax({
        type: "post",
        url: urlList.checkIsAddUser,
        data: {},
        async: false,
        success: function (data) {
            result = data;
        }
    });
    console.info("result = ", result);
    return result;
}

//新增人员
function saveUser() {
    if($("#addSubmit").hasClass("disabled")){
        return ;
    }
    $("#addSubmit").addClass("disabled");
    // 判断是否容许----------start
    var isBilling = 0;
    var remainedAccount = 0;
    $.ajax({
        type: "post",
        url: urlList.queryRemainedQuantity,
        data: {
            type: '2'
        },
        async: false,
        success: function (data) {
            data = eval("(" + data + ")");
            isBilling = data.isBilling;
            if (isBilling == 1) {
                remainedAccount = data.account;
            }
        }
    });
    if (isBilling == 1 && remainedAccount < 1) {
        $("#addSubmit").removeClass("disabled");
        $("#userInfo").modal("hide");
        $.alert({
            title: "警告！",
            message: "账号总数超出系统限制，请联系管理员！",
            type: "warning",
            ok: function () {
            }
        });
        return;
    }
    // 判断是否容许----------end

    //姓名验证
    var userName = $("#addUserName").val();
    if ($.trim(userName).length == 0) {
        showValidated($("#addUserName"), "姓名不能为空", "has-error");
        $("#addSubmit").removeClass("disabled");
        return;
    } else {
        hideValidated($("#addUserName"));
    }
    if ($.trim(userName).length < 2) {
        showValidated($("#addUserName"), "姓名不能小于2个字符", "has-error");
        $("#addSubmit").removeClass("disabled");
        return;
    } else {
        hideValidated($("#addUserName"));
    }
    //邮箱验证
    if (EMAIL_IS_REQUIRED && $.trim($("#addEmail").val()).length == 0) {
        showValidated($("#addEmail"), "邮箱不能为空", "has-error");
        $("#addSubmit").removeClass("disabled");
        return;
    } else {
        hideValidated($("#addEmail"));
    }
    var regexString = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
    //邮箱正则验证
    if (($.trim($("#addEmail").val()).length > 0 || EMAIL_IS_REQUIRED) && !(regexString.test($.trim($("#addEmail").val())))) {
        showValidated($("#addEmail"), "邮箱格式不正确", "has-error");
        $("#addSubmit").removeClass("disabled");
        return;
    } else {
        hideValidated($("#addEmail"));
    }
    //工号验证
    if (JOBNUMBER_IS_REQUIRED && $.trim($("#addJobNumber").val()).length == 0) {
        showValidated($("#addJobNumber"), "工号不能为空", "has-error");
        $("#addSubmit").removeClass("disabled");
        return;
    } else {
        hideValidated($("#addJobNumber"));
    }
    //手机号验证
    var phone = $("#addPhone").val();
    if ($.trim($("#addPhone").val()).length == 0) {
        showValidated($("#addPhone"), "手机号不能为空", "has-error");
        $("#addSubmit").removeClass("disabled");
        return;
    } else {
        hideValidated($("#addPhone"));
    }
    regexString = /^(1[0-9])\d{9}$/;
    //手机号正则验证
    if (!(regexString.test($.trim($("#addPhone").val())))) {
        showValidated($("#addPhone"), "手机号格式不正确", "has-error");
        $("#addSubmit").removeClass("disabled");
        return;
    } else {
        hideValidated($("#addPhone"));
    }
    var addSex = "";
    if ($("#addsex1").parent().hasClass("checked")) {
        addSex = "男";
    } else {
        addSex = "女";
    }
    if ($("#addWorkYear").val() > 100 || $("#addWorkYear").val() < 0) {
        showValidated($("#addWorkYear"), "您输入的工作年限有误", "has-error");
        $("#addSubmit").removeClass("disabled");
        return;
    } else {
        hideValidated($("#addWorkYear"));
    }
    var _classifyLevel = getClassifyLevelParams("addUserform");
    if (_classifyLevel.noFillCount > 0) {
        return;
    } else {
        var err = zyISShow("add");
        if (err) {
            insertUserInfo(addSex, _classifyLevel.calssifyLevel.join(","));
        }
    }
}

function insertUserInfo(addSex, calssifyLevel) {
    var identity = "";
    if ($("#teacherBox").parent().hasClass("checked")) {
        identity = "|001|";
    }
    var dep = "";
    if ($("#addDepId").val() != null) {
        dep = $("#addDepId").val();
    }
    $.ajax({
        type: 'post',
        url: urlList.addUser,
        data: {
            "username": $("#addUserName").val(),
            "tel": $("#addPhone").val(),
            'dep': dep,
            'jobNumber': $("#addJobNumber").val(),
            "email": $("#addEmail").val(),
            "usersex": addSex,
            "identity": identity,
            "calssifyLevel": calssifyLevel,
            "role": $("#addRole").val(),
            "dateTag": dateTag,
            "good": $("#addCc").val(),
            "beif": $("#addBeif").val(),
            "endTime": $("#endTime").val(),
            "workYear": $("#addWorkYear").val(),
            "position": $("#addPosition").val()
        },
        success: function (obj) {
            $("#addSubmit").removeClass("disabled");
            if (obj == 1) {
                caddUser();
                $('#userInfo').modal("hide");
                // getViewTable();
                if (isDep == "true") {
                    getDepInfo();
                } else {
                    getViewTable();
                }
            } else if (obj == 0) {
                showValidated($("#addPhone"), "手机号已存在", "has-error");
            } else if (obj == 2) {
                $.alert({
                    title: "提示!",
                    message: "当前企业只能增加" + userMaxs + "人!",
                    type: "warning",
                    ok: function (modal) {
                    }
                });
            } else if (obj == 3) {
                showValidated($("#addJobNumber"), "人员工号已存在", "has-error");
            }
        }
    });
}

//清空用户添加后的数据
function caddUser() {
    $("#addUserName").val("");
    $("#addPhone").val("");
    $("#uploadImg").val("");
    $("#addEmail").val("");
    $("#addZy1").val("");
    $("#addZyLevel1").val("");
    $("#addZy2").val("");
    $("#addZyLevel2").val("");
    $("#addCj").val("");
    $("#addCjLevel").val("");
    $("#addYx").val("");
    $("#addYxLevel").val("");
    $("#addRole").val("");
    $("#addCc").val("");
    $("#addBeif").val("");
    $("#addDepId").val("");
    $("#endTime").val("");
    if (uTree != null && uTree.text != null) {//清空部门
        uTree.text.val("");
    }
}

function activation(id) {
    $('#activation').modal("show");
    $("#cuserId").val(id);
    $.ajax({
        type: "post",
        async: false,
        url: urlList.selectUser,
        data: {"id": id},
        success: function (data) {
            if (data == null) {
                return;
            }
            data = eval("(" + data + ")");
            $("#cuserName").html("【" + data.res.username + "】已经过期,重新使用前,必须激活该账号!");
        }
    });
}

function alongTime() {
    $("#activeEndTime").val("").attr("readonly", "readonly").removeAttr(
        "onclick");
    $("#changeColorId").css("color", "#999899");
}

function setEndTime() {
    $("#activeEndTime").removeAttr("readonly").attr(
        "onclick",
        "WdatePicker({skin:'whyGreen',dateFmt:'yyyy-MM-dd',minDate:'"
        + getNowDate + "'});");
    $("#changeColorId").css("color", "black");
}

function saveActivePeople() {
    var activite = $('input:radio[name="activite"]:checked').val();
    if (activite == "time") {
        var time = $("#activeEndTime").val();
        if (time == null || time == '') {
            $.alert({
                title: "警告！",
                message: "选择定期有效时间 时，定期有效 时间不能为空！",
                type: "warning",
                ok: function () {
                }
            });
            return;
        }
    }
    $.ajax({
        url: urlList.updateByPrimaryKeySelective,
        type: "post",
        data: {
            id: $("#cuserId").val(),
            endTime: $("#activeEndTime").val()
        },
        success: function (data) {
            $('#activation').modal("hide");
            getDepInfo();
        }
    });
}

var oldSystemName = "";   //修改人员角色时记录该人员原来拥有的角色名称            2017年6月13日14:43:23
var userName = "";         //修改人员角色获取该人名称                            2017年6月13日14:53:54
var oldCustomName = "";

function role(id, userOldRoleId, event, name) {//
    event.stopPropagation();
    custom_chk_value = [];
    system_chk_value = [];
    oldSystemName = "";    // 保证只记录当前某人角色，而不会被其他打开角色锁注入修改  2017年6月13日14:43:07
    if (isRoleMany == "true") {
        if (userOldRoleId != 'null' && userOldRoleId != null) {
            var roleIds = userOldRoleId.split(",");
            $.each(roleIds, function (i, roleId) {
                custom_chk_value.push(roleId);
            });
        }
    }
    $('#userRole').modal("show");
    roleUserId = id;
    userName = name;                //获取该人员名字      2017年6月13日14:54:38
    this.userOldRoleId = userOldRoleId;
    createSystemAndCustomRolelist();
}

function createSystemAndCustomRolelist() {
    $("#userRoleList").empty();
    noneRoleDataDomList.getLoadingLabel();
    $.ajax({
        url: urlList.initSystemRoleListByUserId,
        dataType: "json",
        data: {
            userId: roleUserId
        },
        success: function (data) {
            if (data && data.res == 1) {
                var htmls = initSystemRoleHtml(data.data, "");           //封装系统自带的4个角色  2017年6月13日14:07:39
                htmls = companyRoleLlist(data.companyRoleData, htmls);

                noneRoleDataDomList.emptyParentDom();
                $("#userRoleList").html(htmls);
                $('#userRoleList .i-checks').iCheck({
                    checkboxClass: 'icheckbox_square-green',
                    radioClass: 'iradio_square-green',
                });

                var checkAll = $('#checkRoleAll');
                var checkboxes = $('#userRoleList').find(".i-checks");
                if (checkboxes.filter(':checked').length == checkboxes.length && checkboxes.length > 0) {//checkbox总数和选中的数量相等则全选勾中
                    checkAll.prop('checked', 'checked');//给全选添加checked属性，必须是prop，attr方法无效
                } else {//否则删除全选checkbox checeked属性，removeProp方法无效
                    checkAll.removeAttr('checked');
                }
                checkAll.iCheck('update');//根据状态改变样式
                checkboxes.on('ifChanged', function (event) {//输入框的 checked 或 disabled 状态改变了
                    if (checkboxes.filter(':checked').length == checkboxes.length) {//checkbox总数和选中的数量相等则全选勾中
                        checkAll.prop('checked', 'checked');//给全选添加checked属性，必须是prop，attr方法无效
                    } else {//否则删除全选checkbox checeked属性，removeProp方法无效
                        checkAll.removeAttr('checked');
                    }
                    checkAll.iCheck('update');//根据状态改变样式
                });
                //全选/全不选checkbox
                checkAll.on('ifChecked ifUnchecked', function (event) {
                    if (event.type == 'ifChecked') {
                        checkboxes.iCheck('check');
                    } else {
                        checkboxes.iCheck('uncheck');
                    }
                });
            }
        }
    });
}

//行点击角色时弹出得系统默认角色列表  2017年6月13日14:14:17  start
function initSystemRoleHtml(data, htmls) {
    var oldSyetemRoleName = "";
    $.each(data, function (index, item) {
        var rdo = "";
        var roleName = item.roleName;
        if (roleName != "超级管理员") {
            var shortName = roleName;
            if (item.isCheck == 1) {
                rdo = "checked=\"checked\"";
                oldSyetemRoleName = item.roleName + ",";
            }
            oldSystemName += oldSyetemRoleName;       //拼装在平台中默认角色中此人员所具有的角色     2017年6月13日14:43:38
            if (roleName != null && roleName.length > 38) {
                shortName = roleName.substr(0, 38) + "...";
            }
            var roleRemark = item.roleBak;
            var shortRemark = roleRemark;
            if (shortRemark != null && shortRemark.length > 38) {
                shortRemark = shortRemark.substr(0, 38) + "...";
            }
            var type = "radio";
            if (isRoleMany == "true") {
                type = "checkbox";
            }
            var iHtml = "";
            if (roleName == "系统管理员") {
                iHtml = '<i class="js-icon js-icon1 m-r-sm"></i>';
            } else if (roleName == "内训主管") {
                iHtml = '<i class="js-icon js-icon2 m-r-sm"></i>';
            } else {
                iHtml = '<i class="js-icon js-icon3 m-r-sm"></i>';
            }
            htmls += '<tr style="cursor: pointer" onclick="trCheck(this)">';//checkbox
            htmls += "<td><span class='m-l-xs'><input type='" + type + "' value='" + item.id + "' class='i-checks system' " + rdo + "  name='roles'></span></td>";
            htmls += "<td>";
            htmls += iHtml;
            htmls += '<span title="' + roleName + '">' + shortName + '</span></span><span class="text-navy f12">（系统角色）';
            htmls += "</td>";
            htmls += "<td>";
            htmls += '<span title="' + roleRemark + '">' + shortRemark + '</span>';
            htmls += "</td>";
            htmls += "</tr>";
        }
    });
    return htmls;
}

//行点击角色时弹出得系统默认角色列表  2017年6月13日14:14:17  end
//行点击角色时弹出的系统添加的角色列表   2017年6月13日14:34:16  start
function companyRoleLlist(datalist, htmls) {
    $.each(datalist, function (i, obj) {
        var oldCustomRoleName = "";
        var rdo = "";
        if (obj.count > 0) {
            rdo = "checked=\"checked\""
            oldCustomRoleName = obj.roleName + ",";
        }
        oldSystemName += oldCustomRoleName;   //拼装在该企业平台中该企业添加的角色中此人员所具有的角色        2017年6月13日14:43:46
        var roleName = obj.roleName;
        var shortName = roleName;
        if (roleName != null && roleName.length > 30) {
            shortName = roleName.substr(0, 30) + "...";
        }
        var roleRemark = obj.roleBak;
        var shortRemark = roleRemark;
        if (shortRemark != null && shortRemark.length > 30) {
            shortRemark = shortRemark.substr(0, 30) + "...";
        }
        var type = "radio";
        if (isRoleMany == "true") {
            type = "checkbox";
        }
        htmls += '<tr style="cursor: pointer" onclick="trCheck(this)">';//checkbox
        htmls += "<td><span class='m-l-xs'><input type='" + type + "' value='" + obj.id + "' class='i-checks custom' " + rdo + "  name='roles'></span></td>";
        htmls += "<td>";
        htmls += '<i class="js-icon js-icon4 m-r-sm"></i><span title="' + roleName + '">' + shortName + '</span>';
        htmls += "</td>";
        htmls += "<td>";
        htmls += '<span title="' + roleRemark + '">' + shortRemark + '</span>';
        htmls += "</td>";
        htmls += "</tr>";
    });
    return htmls;
}

//行点击角色时弹出的系统添加的角色列表   2017年6月13日14:34:16  end
function saveRole() {
    var roleCustomId = '';
    var roleSystemId = '';
    if (isRoleMany == "true") {
        $('.custom').each(function () {
            if ($(this).is(":checked")) {
                var n = custom_chk_value.indexOf($(this).val());
                if (n < 0) {
                    custom_chk_value.push($(this).val());
                }
            } else {
                var n = custom_chk_value.indexOf($(this).val());
                if (n != -1) {
                    custom_chk_value.splice(n, 1);
                }
            }
        });
        roleCustomId = custom_chk_value.join(",");
        $('.system').each(function () {
            if ($(this).is(":checked")) {
                var n = system_chk_value.indexOf($(this).val());
                if (n < 0) {
                    system_chk_value.push($(this).val());
                }
            }
        });
        roleSystemId = system_chk_value.join(",");
    } else {
        roleCustomId = $('.custom:checked').val();
        roleSystemId = $('.system:checked').val();
    }
    $.ajax({
        url: urlList.bandRoleNew,
        type: "post",
        async: false,
        data: {
            "users": roleUserId,
            "userName": userName,
            "roleCustomId": roleCustomId,
            "roleSystemId": roleSystemId,
            "oldCustomName": oldCustomName,
            "oldSystemName": oldSystemName
        },
        success: function (data) {
            if (data == null) {
                return;
            }
            oldSystemName = "";
            oldCustomName = "";
            $('#userRole').modal("hide");
            getViewTable();
        },
        cache: false,
        error: function (xhr, errorText) {
            // errorRedirect(xhr,errorText);
        }
    });
}

function allclear(id) {
    if (id > 0) {
        $.ajax({
            url: urlList.delBandRole,
            type: "post",
            async: false,
            data: {
                "users": id
            },
            success: function (data) {
                if (data == null) {
                    return;
                }
            },
            cache: false,
            error: function (xhr, errorText) {
                // errorRedirect(xhr,errorText);
            }
        });
    }
}

//查询获取分组列表
function loadRoleListTree() {
    $.ajax({
        type: 'post',
        url: urlList.getRoleTree,
        async: false,
        data: {},
        datatype: 'json',
        success: function (data) {
            if (data == null) {
                return;
            }
            data = eval("(" + data + ")");
            roleListTree = data;
        }
    });
}

function group(id, depList) {
    groupUserId = id;
    var params = {"userId": id};
    $('#userGroup').modal("show");
    inittreeList(params, depList);
}

function inittreeList(params, depList) {
    $.ajax({
        url: urlList.getDepInfosPermByUserId,
        type: "post",
        data: params,
        async: false,
        success: function (data) {
            if (data == null) {
                return;
            }
            var setting;
            if (isDepMany == 'true') {
                setting = $.extend({}, GroupSelector.add_Or_Up_ztree_settings);
            } else {
                setting = settings;
            }
            $.fn.zTree.init($("#treeDemo"), setting, eval(data));
            var treeDemoObj = $.fn.zTree.getZTreeObj("treeDemo");//获取ztreeObject对象
            if (depList == "") {
                var selectNode = treeDemoObj.getNodeByParam("id", "-1");
                treeDemoObj.checkNode(selectNode, true, true);
                treeDemoObj.selectNode(selectNode, false);
            } else {
                var str = depList.split(",");
                for (var i = 0; i < str.length; i++) {
                    var st = str[i].split("|");
                    var selectNode = treeDemoObj.getNodeByParam("id", st[1]);
                    treeDemoObj.checkNode(selectNode, true, true);
                    treeDemoObj.selectNode(selectNode, false);
                }
            }
        },
        cache: false,
        error: function (xhr, errorText) {
        }
    });
}

/**
 * 保存分组设定
 * @returns
 */
function saveDepUser() {
    var treeObj = $.fn.zTree.getZTreeObj("treeDemo");
    var nodes = treeObj.getCheckedNodes();
    var depCode = "";
    for (var i = 0; i < nodes.length; i++) {
        depCode += nodes[i].id + ",";
    }
    if (depCode == "") {
        $.alert({
            title: "警告！",
            message: "请选择部门",
            type: "warning",
            ok: function (modal) {

            }, cancel: function (modal) {
            }
        });
        return false;
    }
    $.ajax({
        url: urlList.saveDepUser, // depInfo/saveDepUser
        type: "post",
        data: {
            "depCode": depCode,
            "userId": groupUserId
        },
        success: function (data) {
            if (data == "0") {
                $.alert({
                    title: "提示！",
                    message: "保存部门失败",
                    type: "warning",
                    ok: function (modal) {

                    }
                });
            }
            if (data == "1") {
                $('#userGroup').modal("hide");
                // getViewTable();
                getDepInfo();
            }
        },
        cache: false,
        error: function (xhr, errorText) {
            // errorRedirect(xhr,errorText);
        }
    });
}

/******************END 分组列表**************************/
function loadDepPermListTree() {
    $.ajax({
        type: 'post',
        url: urlList.getDepInfosPermByUserId,
        async: false,
        datatype: 'json',
        success: function (data) {
            if (data == null) {
                return;
            }
            data = eval("(" + data + ")");
            depPermListTree = data;
        }
    });
}

function loadDepPermListTreeForDep() {
    $.ajax({
        type: 'post',
        url: urlList.getDepInfosPermByUserId,
        async: false,
        data: {
            type: "select2"
        },
        datatype: 'json',
        success: function (data) {
            if (data == null) {
                return;
            }
            data = eval("(" + data + ")");
            depPermListTree = data;
        }
    });
}

//查询获取分组列表
function loadDepListTree() {
    $.ajax({
        type: 'post',
        url: urlList.getDepSelectTree,
        async: false,
        data: {
            type: "select2"
        },
        datatype: 'json',
        success: function (data) {
            if (data == null) {
                return;
            }
            data = eval("(" + data + ")");
            depListTree = data;
            isCheckedTree = "";
            if (isCheckedTree == "" && data.length > 0) {
                isCheckedTree = data[0].isCheckedName;
            }
        }
    });
}

function moveUser() {
    var uids = "";
    $("#userList input").each(function () {
        if ($(this).parent().hasClass("checked")) {
            uids += $(this).val() + ",";
        }
    });
    if (uids.length < 1) {
        $.alert({
            title: "警告",
            message: "请选择要移动的人员信息",
            type: 'warning',
            ok: function () {
            }
        });
        return false;
    }
    var treeObj = $.fn.zTree.getZTreeObj("yidongtree");
    var nodes = treeObj.getCheckedNodes();
    var toDepId = "";
    for (var i = 0; i < nodes.length; i++) {
        toDepId = nodes[i].code;
    }
    if (toDepId == undefined) {
        toDepId = -2;
    }

    if (toDepId == "") {
        $.alert({
            title: "警告！",
            message: "请选择部门",
            type: "warning",
            ok: function (modal) {
            }
        });
        return false;
    }
    uids = uids.replaceAll("undefined,", "");
    $.ajax({
        url: urlList.moveUsers,
        type: "post",
        data: {
            "userId": uids,
            "depId": choseDepId,
            "toDepId": toDepId
        },
        success: function (data) {
            if (data == null) {
                return;
            }
            data = eval("(" + data + ")");
            if (data.res == 1) {
                $('#yidongmodal').modal("hide");
                // getViewTable();
                getDepInfo();
            } else {
                $.alert({
                    title: "提示！",
                    message: "移动失败",
                    type: "warning",
                    ok: function (modal) {
                    }
                });
            }
        },
        cache: false,
        error: function (xhr, errorText) {
        }
    });
}

function trCheck(dom) {
    if ($(dom).find("td").find("div").hasClass("checked")) {
        $(dom).find("td").find("div").removeClass("checked");
        $(dom).find("td").find("div").find('input[name="roles"]').removeAttr('checked');
    } else {
        $(dom).find("td").find("div").addClass("checked");
        $(dom).find("td").find("div").find('input[name="roles"]').prop('checked', 'checked');
    }
    $(dom).find("td").find("div").find('input[name="roles"]').iCheck('update');//根据状态改变样式
}

function createCode() {
    window.location.href = urlList.createCode;
}

function unSolveTotal() {
    $.ajax({
        type: "post",
        url: urlList.countUntotalPeopleByCreateId,
        data: {},
        dataType: "json",
        success: function (data) {
            var $_unSolveTotal = $("#unSolveTotal");
            if (data && data > 0) {
                $_unSolveTotal.html(data);
                $_unSolveTotal.parent().show();
            } else {
                $_unSolveTotal.parent().remove();
            }
        }
    });
}
