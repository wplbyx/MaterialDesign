function queryMyMissionByCondition(){
	$("#mine-renwu-list-1").empty();
    page = 0;
    queryMyMission(page);
}

function queryMyMission(page) {
    var missionName = $("#keyWord").val();
    var state = $("#state").find(".btn-primary").attr("data-status");
    if(state==1){
        state ="110";
    }if(state==2){
        state ="001";
    }if(state==""){
        state ="111";
    }
    var missionType = "3,2,1";
    var pageSize=$.cookie("myMissionList");
    if(pageSize==null||pageSize==""){
        pageSize=10;
    }
    var req_data = {
        pageNum: page,
        pageSize: pageSize,
        missionType: missionType,
        missionName: missionName,
        state: state
    };
    $("#mine-renwu-list-1").empty();
    $("#myMissionListpage").empty();
    empty.getLoadingLabel();
    $.ajax({
        url : url,
        type : "post",
        data : req_data,
        dataType : "json",
        success : function(data) {
            data = data.data.page;
            if (data == null) {return;}
            new PaginationPage("myMissionList", queryMyMission, data,true);
            if(data.items && data.items.length>0){
                empty.emptyParentDom();
                getContentHTML(data.items);
            }else{
                empty.getNoneDataLabel("暂无任务~");
            }
        },
        cache : false,
        error : function(xhr, errorText) {
        }
    });
}

/**
 * 转换后台传过来的任务数据
 * @param mission
 */
function toMissionModal(mission){
    var data = {
        smallClass:"",
        process:"",
        fontHtml:"",
        adviceAndOperate:'<td class="col-sm-3"></td><td></td>',
        finishCount: !mission.finishCount ? 0 : mission.finishCount,
        realCount: !mission.realCount ? 0 : mission.realCount,
        planCount: !mission.planCount ? 0 : mission.planCount,
        sourceCount: mission.sourceCount,
        sourceUnit: mission.missionType == 1 ? "题" : "课件",
        missionName: mission.missionName,
        sourceName: !mission.sourceName ? "该资源被删除或者不存在" : mission.sourceName,
        startTime: setNewDateTimeFormat(mission.startTimeStr),
        endTime: setNewDateTimeFormat(mission.endTimeStr)
    };
    data.sourceNameTitle = data.sourceName;
    data.missionProcess = parseInt(data.finishCount / data.sourceCount * 100);
    if (data.sourceName.length > 21) {
        data.sourceName = data.sourceName.substring(0, 20) + "...";
    }
    if(mission.missionStatusType == 0){//未开始
        data.missionStatus = "未开始";
        data.smallClass="label-warning";
    } else if((mission.missionStatusType == 1 || mission.missionStatusType == 2 || mission.missionStatusType == 3)&&mission.process<100){
        //因为可能出现学完任务后又新增课程的情况，所以更改为以进度来算
        data.missionStatus = "进行中";
        data.smallClass="label-primary";
        data.fontHtml = '<font class="text-lightgray m-l-sm">|</font>';
        data.process ='<div class="col-sm-6" style="max-width: 150px;width: 100%;">'
                        + '<div class="progress progress-mini m-t-sm relative" style="">'
                            + '<div style="width: '+ data.missionProcess +'%;" class="progress-bar"></div>'
                        + '</div>'
                    + '</div>'
                    + '<div class="col-sm-3 no-padding f12"  style="margin-top: 3px;">' + data.finishCount + '/'+ data.sourceCount +  data.sourceUnit +'</div>';;
        data.adviceAndOperate = '<td><span class="text-lightgray">今日建议：<font>'+ data.planCount +'</font></span></td>'
                              + '<td class="text-right"><button class="btn btn-outline btn-primary" onclick="toExcute(' + mission.id + ',' + mission.missionStatusType + ',' + mission.missionType + ',this)">去学习</button></td>';
    }else if(mission.missionStatusType == 6){
        data.missionStatus = "已失效";
    }else if(mission.missionStatusType == 7){
        data.missionStatus = "已结束";
        data.fontHtml = '<font class="text-lightgray m-l-sm">|</font>';
        data.process ='<div class="col-sm-6" style="max-width: 150px;width: 100%;">'
            + '<div class="progress progress-mini m-t-sm relative" style="">'
            + '<div style="width: '+ data.missionProcess +'%;" class="progress-bar"></div>'
            + '</div>'
            + '</div>'
            + '<div class="col-sm-3 no-padding f12"  style="margin-top: 3px;">' + data.finishCount + '/'+ data.sourceCount +  data.sourceUnit +'</div>';
    }
    else if(mission.missionStatusType == 4 || mission.missionStatusType == 5 || mission.missionStatusType == 8||mission.process==100){
        data.missionStatus = "已完成";
        data.smallClass="label-success";
    }
    return data;
}

function getContentHTML(data){
    var html = "";
    $.each(data, function (index, item) {
        var data=toMissionModal(item);
        var clickHtml = "";
        if(item.missionStatusType == 1 || item.missionStatusType == 2 || item.missionStatusType == 3){
            clickHtml = 'class="cursor_pointer" onclick="toExcute(' + item.id + ',' + item.missionStatusType + ',' + item.missionType + ')"';
        }
        html += '<tr '+ clickHtml + '>'
                    + '<td class="col-sm-1">'
                        + '<small class="label '+ data.smallClass +' f12 m-l-sm">'+ data.missionStatus +'</small>'
                    + '</td>'
                    + '<td>'
                        + '<div class="f14 font-bold m-b-xs">'
                            + data.missionName
                        + '</div>'
                        + '<div class="f12">'
                            + '学习内容：<font title="'+ data.sourceNameTitle +'">'+ data.sourceName +'</font>'
                            + '<span class="p-w-xs text-lightgray">|</span>'
                            + '<span class="f12" style="margin-top: 3px;">'+ data.sourceCount +  data.sourceUnit +'</span>'
                        + '</div>'
                        + '<div>'
                            + '<span class="f12 pull-left" style="margin-top: 3px;">'+ data.startTime +'&nbsp;~&nbsp;'+ data.endTime + data.fontHtml + '</span>'
                            + data.process
                        + '</div>'
                    + '</td>'
                    + data.adviceAndOperate
                + '</tr>';

    });
    $("#mine-renwu-list-1").html(html);
}


function toExcute(id, type, missionType, dom) {
    var count = $.cookie('practiceCount');
    if (count == undefined)
        count = 5;
    if (missionType == 1) {
    	$.ajax({
            type: "post",
            url: queryMissionQuesBankStatus,
            data: {missionId: id},
            dataType: "json",
            success: function (data) {
            	if(data.res == 1){
            		window.location.href = studyUrl + id + "?practiceCount=" + count;
            	}else if(data.res == -10){
            		$.alert({
            	        title: "提示",
            	        message:"该练习题库已经失效，请您联系管理员！",
            	        type: "warning",
            	        ok: function () {
            	        }
            	    });
            	}else if(data.res == -11){
            		$.alert({
            	        title: "提示",
            	        message:"该练习任务题库已被下架，不需要您继续完成哦！",
            	        type: "warning",
            	        ok: function () {
            	        }
            	    });
            	}else {
            		$.alert({
            	        title: "提示",
            	        message:"该练习任务出现异常，请您联系系统管理员！",
            	        type: "warning",
            	        ok: function () {
            	        }
            	    });
            	}
            }
        });
    } else if (missionType == 2 || missionType == 3) {
        $.ajax({
            type: "post",
            url: studyMission,
            data: { missionId: id},
            dataType: "json",
            success: function (data) {
                if (data != null && data["res"] == 1) {
                    if (data["missionStatus"] == 2) {
                    	if(missionType == 3){
                            forwordHtmlHref(signatureUrl, gotoHsMeansInfo, {id:data["courseId"],missionId:id});
                    		//window.location.href = gotoHsMeansInfo + "?id=" + data["courseId"] + "&missionId=" + id;
                        }else{
                            forwordHtmlHref(signatureUrl, gotoMeansInfo, {id:data["courseId"],missionId:id});
                            //window.location.href = gotoMeansInfo + "?id=" + data["courseId"] + "&missionId=" + id;
                    	}
                    } else if (data["missionStatus"] == 1) {
                    	$.alert({
                	        title: "提示",
                	        message:"任务未开始！",
                	        type: "info",
                	        ok: function () {
                	        }
                	    });
                        /*$(dom).attr("title", "任务未开始");
                        $(dom).addClass("disabled");
                        $(dom).removeClass("green");
                        $(dom).addClass("grey-hs");*/
                    } else if (data["missionStatus"] == 3) {
                    	$.alert({
                	        title: "提示",
                	        message:"任务已经结束！",
                	        type: "info",
                	        ok: function () {
                	        }
                	    });
                        /*$(dom).attr("title", "任务已经结束");
                        $(dom).addClass("disabled");
                        $(dom).removeClass("green");
                        $(dom).addClass("grey-hs");*/
                    } else {
                    	$.alert({
                	        title: "提示",
                	        message:"任务对应的课程已删除！",
                	        type: "info",
                	        ok: function () {
                	        }
                	    });
                        /*$(dom).attr("title", "任务对应的课程已删除");
                        $(dom).addClass("disabled");
                        $(dom).removeClass("green");
                        $(dom).addClass("grey-hs");*/
                    }
                } else if (data != null && data["res"] == 2) {
                	$.alert({
            	        title: "提示",
            	        message:"任务对应的课程未发布！",
            	        type: "info",
            	        ok: function () {
            	        }
            	    });
                    /*$(dom).attr("title", "任务对应的课程未发布");
                    $(dom).addClass("disabled");
                    $(dom).removeClass("green");
                    $(dom).addClass("grey-hs");*/
                } else {
                	$.alert({
            	        title: "提示",
            	        message:"任务对应的课程已删除！",
            	        type: "info",
            	        ok: function () {
            	        }
            	    });
                    /*$(dom).attr("title", "任务对应的课程已删除");
                    $(dom).addClass("disabled");
                    $(dom).removeClass("green");
                    $(dom).addClass("grey-hs");*/
                }
            }
        });
    }
}