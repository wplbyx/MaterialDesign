var noneDataDom = new Label({parentDom:$("#noneDataDom")});

$(function() {
	//查询绑定回车事件
	selectBindEnter("keyword",getMissionList,2);

	getMissionList(0);//查询
	
	$("#missionStatus,#type").on("click", "a", function(){
		if(!$(this).hasClass("active")){
            $(this).siblings(".file-control").removeClass("active");
            $(this).removeClass("active");
            $(this).addClass("active");
            getMissionList(0);//查询
        }
	});
	/*$("#type").on("click",function(){
		if(!$(this).hasClass("active")){
            $(this).siblings(".file-control").removeClass("active");
            $(this).removeClass("active");
            $(this).addClass("active");
            getMissionList(1);//查询
        }
	});*/
	 if(UserType==2){
    	searchUserInfoMdminList("createId","mission");
    }
});

function dateTimeChangeEvent(){
	getMissionList(0);//查询
}

// 获取列表
function getMissionList(pageNumber){
    if($("#keyword").val()!=null){
        if(!checkSpecialCharacter($("#keyword").val())){
            alertWrong("请检查关键字,不能输入特殊字符！");
            return;
        }
    }
	pageNum=pageNumber;
	var pageSize=$.cookie("missionList");
	if(pageSize==null||pageSize=="")
	{
		pageSize=10;
	}
	var status = $("#missionStatus").find(".active").data("status");
	var type = $("#type").find(".active").data("status");
	
	var createId=$("#createId").val();
    if(createId==null){
    	createId=-1;
    }
	var data = {
		"keyword":$("#keyword").val(),
		"missionName":$("#missionName").val(),
		"status": status == "wfb" ? 0 : status == "yfb" ? 1 : status == "yfq" ? 2 : "",
		"executeStatus": status == "wks" ? 0 : status == "jxz" ? 1 : status == "yjs" ? 2 : "",
		"id":$("#missionId").val(),
		"missionType" : type,
		"beginTime":$("#startTime").val(),
		"endTime":$("#endTime").val(),
		pageNumber:pageNumber,
		pageSize:pageSize,
		"createId":createId
	};
	$("#content").empty();
	$("#missionPagepage").empty();
	noneDataDom.getLoadingLabel();
	$.ajax({
		type : "post",
		url : urls.queryList,
		data: data,
		dataType: "json",
		success : function(data) {
			data = data.data;
			if(data==null){return;}
			var nowDate = data.nowDate;
			data = data.pagination;
			new PaginationPage("missionPage", getMissionList,data,true);
			if(data.items && data.items.length > 0){
				noneDataDom.emptyParentDom();
				companyTable(data, nowDate, $("#content"));
			}else{
				noneDataDom.getNoneDataLabel();
			}
		}
	});
}


function copyMission(missionId){
	$.ajax({
		type: "post",
	    url: urls.createTempMission,
	    data : {
	    	id : missionId
	    },
	    dataType: "json",
	    success: function (data) {
	    	if(data==null){
	    		return;
	    	}
	        if (data.res == 1) {
	        	window.location.href=urls.copyMission+"/"+data.missionTempId;
	        }else{
	        	$.confirm({
	                title: "警告",
	                message:"亲，复制任务存在系统异常，请稍后再试！",
	                type: "warning",
	                ok: function () {
	                }
	            });
	        }
	    }
	});
}
	// 渲染人员列表TABLE
function companyTable(data, nowDate, domId){
	var d = eval(data.items);
	var domHtml = '';//
//	if(d.length==0){
//		if($("#missionName").val()==""&&$("#status").val()==""&&$("#executeStatus").val()==""&&$("#missionId").val()==""&&$("#startTime").val()==""&&$("#endTime").val()==""){
//			noneMission.getNoneDataLabel('暂未创建任务,赶紧去<a href="javascript:addMission();" >创建</a>吧！');
//		}else{
//			noneMission.getNoneDataLabel('没有查询到相关的任务！');
//		}
//	}else{
//		noneMission.emptyParentDom();
//	}
//	error=false;
//	$("#selectAll").parent().removeClass("checked");
//	$("#selectAll").iCheck("uncheck");
	for(var i = 0;i < d.length;i++){
		var missionTypeName="";
		var str='<div class="btn-group">';
//		var dis='<span style="float:left;margin-left: 5px; height: 19px;width: 19px;">&nbsp;</span>';
		if(d[i].status==0){//未开始 .Format("yyyy-MM-dd hh:mm")
//			dis='<div class="checker"><span id="' + d[i].id + '"><input  type="checkbox" class="i-checks"  onclick="signcheck(this)"></span></div>';
			str+='<button class="btn-white btn btn-xs" onclick="updateMission('+d[i].id+',event)" ><span>编辑</span> </button>';
			str+='<button class="btn-white btn btn-xs" onclick="del('+d[i].id+',event)" ><span>删除</span> </a>';
		}else{
			if(((new Date(d[i].startTime))>new Date(nowDate) || (new Date(d[i].startTime))<new Date(nowDate) &&(new Date(d[i].endTime))>new Date(nowDate)) && d[i].status==1){
				str+='<button class="btn-white btn btn-xs" onclick="forwordMissionInfo('+d[i].id+',event)" ><span>编辑</span> </a>';
			}else{
				str+='<button class="btn-white btn btn-xs" onclick="forwordMissionInfo('+d[i].id+',event)" ><span>详情</span> </a>';
			}
			if(d[i].status==2||(new Date(d[i].endTime))<new Date(nowDate)){
				str+='<button class="btn-white btn btn-xs" onclick="monitorMission('+d[i].id+',event)" ><span>统计</span> </a>';
			}else{
				str+='<button class="btn-white btn btn-xs" onclick="monitorMission('+d[i].id+',event)" ><span>监控</span> </a>';
			}
		}
		
		str+='</div>';
		var statusName="";
		if(d[i].status==0){
			 statusName="<small class='label label-warning'>未发布</small>";
		}else if(d[i].status==1){
//			 statusName="<small class='label label-primary'>已发布</small>";
			if((new Date(d[i].startTime))>new Date(nowDate)){
				statusName="<small class='label label-warning'>未开始</small>";
			}else if((new Date(d[i].startTime))<new Date(nowDate) &&(new Date(d[i].endTime))>new Date(nowDate)){
				statusName="<small class='label label-danger'>进行中</small>";
			}else if((new Date(d[i].endTime))<new Date(nowDate)){
				statusName="<small class='label label-text'>已结束</small>";
			}
		}else if(d[i].status==2){
			 statusName="<small class='label label-text'>已废弃</small>";
		}
		var userName="";
		var userEndTime="";
		var isUsing="";
		if(d[i].createrUser==0){
			userName="超级管理员";
		}else{
			userName=d[i].userName;
			userEndTime=d[i].userEndTime;
			isUsing=d[i].isUsing;
			
			if(isUsing==0 || userName=="" || userName==null) {
				userName+='<span class="label label-default">此人已删除</span>';
			}else  if(userEndTime != undefined 
				&& new Date(userEndTime).getTime() <= new Date().getTime()){
				userName+='<span class="label label-default">此人已冻结</span>';
			}
	
//			if(userName==""||userName==null){
//				userName='<span class="label label-important">用户已删除</span>';
//			}
		}
		var  missionName= d[i].missionName;
		if(missionName.length>15){
			missionName=missionName.substring(0,15)+"...";
		}
		
		var missionType = d[i].missionType;
		if(missionType == 1){
			missionType = "练习";
		}else if(missionType == 2 || missionType == 3){
			missionType = "课程";
		}
		var path = d[i].picPath;
		var imgPath = '';
		if (path == "" || path == null || path == "null" || path == '"null"') {
			imgPath = urls.imgPath;
		} else {
			imgPath = img_read_path + path + "!200_200.png";
		}
		imgPath = headIcon.createSmallHeaderIconForList(imgPath, userName, d[i].createrUser)
		if(d[i].status==0){ // 编辑
			domHtml += '<tr style="cursor: pointer" onclick="updateMission('+d[i].id+',event)">' 
		}else{// 详情
			domHtml += '<tr style="cursor: pointer" onclick="forwordMissionInfo('+d[i].id+',event)">' 
		}
		
		domHtml += '<td>' + statusName + '</td>'
			+ '<td class="hidden-xs">'+d[i].id+'</td>'
			+ '<td><div><a class="text-sprit" title="'+d[i].missionName+'"  href="'+urls.missionInfo+'?id='+d[i].id+'">' + missionName + '</a></div>';

		/**时间规范开始**/
		/**开始时间**/

		var startTime = setNewDateTimeFormat(d[i].startTime);
		var endTime = setNewDateTimeFormat(d[i].endTime);

		domHtml += '<div class="f12">'+startTime + '~'+ endTime+ '</div>';

		/**时间规范结束**/

       	domHtml +='</td>'
       		+ '<td class="hidden-xs">' + missionType + '</td>'
       		+ '<td class="hidden-xs">' + imgPath + "&nbsp;" + userName + '</td>'
       		+ '<td class="hidden-xs">' + d[i].userCount + '</td>'
       		//+ '<td class="hidden-xs">' + (new Date(d[i].startTime)).Format("yyyy-MM-dd hh:mm") + '</td>'
       		//+ '<td class="hidden-xs">' +(new Date(d[i].endTime)).Format("yyyy-MM-dd hh:mm") + '</td>'
       		+ '<td>'+str + '</td>' 
       		+ '</tr>';
	}
	domId.append(domHtml);
	
//	$('.i-checks').iCheck({//渲染checkbox
//        checkboxClass: 'icheckbox_square-green',
//        radioClass: 'iradio_square-green',
//    });
//    
//    allChecked(checkboxes);
}

function forwordMissionInfo(id,event){//跳转详情页
	event.stopPropagation();
	window.location.href = urls.missionInfo + "?id=" + id;
}

function updateMission(id,event){//跳转修改页面
	event.stopPropagation();
	window.location.href = urls.updateMission + "?id=" + id;
}

function monitorFileMissionPage(id){//跳转监控页面
	window.location.href = urls.monitorFileMissionPage + "?id=" + id;
}


function addMission(){
	$.ajax({
		type: "post",
	    url: urls.createTempMission,
	    dataType: "json",
	    success: function (data) {
	    	if(data==null){
	    		return;
	    	}
	        if (data.res == 1) {
	        	window.location.href=urls.addMission+"/"+data.missionTempId;
	        }else{
	        	$.confirm({
	                title: "警告",
	                message:"亲，新增任务存在系统异常，请稍后再试！",
	                type: "warning",
	                ok: function () {
	                }
	            });
	        }
	    }
	});
}



function scrapMission(id){
	$.confirm({
        title: "提示",
        message: "任务已发布，一旦废弃后学员将无法继续学习，确定废弃吗？",
        type: "warning",
        ok: function () {
            $.ajax({
                type: "post",
                url: urls.scrapMission,
                data: {
                    "id": id
                },
                dataType: "json",
                success: function (data) {
                    if (data.res == 1) {
                    	getMissionList(0);
                    }
                }
            });
        }
    });
}
function publishMission(id,userCount,sourceCount){
	$.confirm({
        title: "提示",
        message:  "任务发布后将不可以修改，确定发布吗？",
        type: "warning",
        ok: function () {
            $.ajax({
                type: "post",
                url: urls.publishMission,
                data: {
                    "id": id,
                    "status":status
                },
                dataType: "json",
                success: function (data) {
                	$("#missionPublish").attr("class","modal-alert modal fade white in");
					$("#missionPublish").find(".modal-header").hide();
					$("#missionPublish").modal("show",{keyboard:false});
                    if (data.res == 1) {
                    	$("#publishOK").show();
                    	setTimeout(function(){
							$("#missionPublish").attr("class","modal hide mostsmall-modal in");
							$("#missionPublish").modal("hide");
						}, 1000);
                    	getMissionList(0);
                    }else if (data.res == 0) {
                    	$("#publishError").show();
						setTimeout(function(){
							$("#missionPublish").attr("class","modal hide mostsmall-modal in");
							$("#missionPublish").modal("hide");
						}, 1000);
                    }else if (data.res == -1) {
//                    	toUpdate(id,"学习人员不能为空，确定去修改吗？");
                    }else if (data.res == -2) {
                    	toUpdate(id,"客观题不能为空，确定去修改吗？");
                    }else if (data.res == -3) {
                    	toUpdate(id,"结束时间已结束无法发布，确定去修改吗？");
                    }
                    else if (data.res == -4) {
                    	toUpdate(id,"学习文件数为零，需要修改课程，确定去修改吗？");
                    }
                }
            });
        }
    });
}
function toUpdate(id,msg){
	$.confirm({
        title: "提示",
        message:msg,
        type: "warning",
        ok: function () {
        	window.location.href=urls.updateMission+"?id="+id;
        }
    });
}

//全选 --> 列表项
function allChecked(domObj) {
	checkboxes = $('#content').find(".i-checks");
	checkboxes.on('ifChanged', function(event){//输入框的 checked 或 disabled 状态改变了
        if(checkboxes.filter(':checked').length == checkboxes.length) {//checkbox总数和选中的数量相等则全选勾中
          	checkAll.prop('checked', 'checked');//给全选添加checked属性，必须是prop，attr方法无效
        } else {//否则删除全选checkbox checeked属性，removeProp方法无效
          	checkAll.removeAttr('checked');
        }
        checkAll.iCheck('update');//根据状态改变样式
    });
	
	 //全选/全不选checkbox
    checkAll.on('ifChecked ifUnchecked', function(event) {
      if (event.type == 'ifChecked') {
        checkboxes.iCheck('check');
      } else {
        checkboxes.iCheck('uncheck');
      }
    });
}

function del(id,event){
	event.stopPropagation();
	$.confirm({
        title: "提示",
        message: "确认删除任务记录吗？",
        type: "warning",
        ok: function () {
            $.ajax({
                type: "post",
                url: urls.deleteMission,
                data: {
                    ids: id
                },
                dataType: "json",
                success: function (data) {
                    if (data.res == 1) {
                    	getMissionList(0);
                    }
                }
            });
        }
    });
}
//批量删除
function batchDeleteRecord() {
	var n = 0;
	var ids = new Array();
	$("#content").find(".i-checks").each(function(){
        if($(this).is(":checked")){
            ids[n] = $(this).parent().parent().attr("id");
            n++;
        }
    });
//		alert("共 " + n + " 个" + "\r\n" + ids.join(","));
	if(n == 0){
		$.alert({
			title: "提示!",
			message: "请选择需要删除的记录",
			type: "warning",
			ok: function (modal) {
			}
		});
		return false;
	}
    $.confirm({
        title: "提示",
        message: "确认删除任务记录吗？",
        type: "warning",
        ok: function () {
            $.ajax({
                type: "post",
                url: urls.deleteMission,
                data: {
                    ids: ids.join(",")
                },
                dataType: "json",
                success: function (data) {
                    if (data.res == 1) {
                    	getMissionList(0);
                    }
                }
            });
        }
    });
}
function monitorMission(missionId,event){
	event.stopPropagation();
	window.location.href=urls.monitorFileMissionPage +"?id="+missionId;;
}

//日期格式化
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};

