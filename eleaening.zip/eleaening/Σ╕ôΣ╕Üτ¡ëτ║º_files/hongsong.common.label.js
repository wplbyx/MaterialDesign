/**
 * 使用实例
 * new Label({content:"321321321",parentDom:$(".portlet-body")}).getNoneDataLabel();
 * 和table等数据容器同级
 *
 * functions: 
 *  1.getNoneDataLabel
 *  2.getLoadingLabel
 * 
 * 
 */

var Label = function (config) {
    if (config['parentDom']) {
        this.parentDom = config['parentDom'];
    } else {
        alert("error... parentDom null");
    }
};

//没有数据
Label.prototype.getNoneDataLabel = function (content,type) {
    if(type){
        if (type == 'exam'){
            this.labelDom = this.init("NONE_DATA_EXAM");
        }else if (type == 'course'){
            this.labelDom = this.init("NONE_DATA_COURSE");
        }else if (type == 'collect'){
            this.labelDom = this.init("NONE_DATA_COLLECT");
        }else if(type == 'role'){
            this.labelDom = this.init("NONE_DATA_ROLE");
        }else if(type == 'questionReport'){
            this.labelDom = this.init("NONE_DATA_QUESTIONREPORT");
        }else if(type == 'questionReportOK'){
            this.labelDom = this.init("NONE_DATA_QUESTIONREPORT_OK");
        }else if(type == 'report'){
            this.labelDom = this.init("NONE_DATA_REPORT");
        }else if(type == 'qx'){
            this.labelDom = this.init("NONE_DATA_QX");
        }else if(type == 'content'){
            this.labelDom = this.init("NONE_DATA_CONTENT");
        }
    }else{
        this.labelDom = this.init("NONE_DATA");
    }
    if (content) {
        $(this.labelDom).find("p").html(content);
    } else {
        $(this.labelDom).find("p").html("空空如也...");
    }
    $(this.parentDom).html(this.labelDom);
    this.contentsVertical();
};

//loading状态，旋转的圆圈。
Label.prototype.getLoadingLabel = function () {
    this.labelDom = this.init("LOADING_LABEL");
    $(this.parentDom).html(this.labelDom);
    this.contentsVertical();
};

Label.prototype.emptyParentDom = function () {
    $(this.parentDom).empty();
};

Label.prototype.remove = function (dom) {
    $(dom).remove();
};

Label.prototype.show = function (dom) {  
    $(dom).show();
};

Label.prototype.hide = function (dom) {
    $(dom).hide();
};

Label.prototype.store = {
    NONE_DATA: "<div class='zwt zwt-sj'><p>${content}</p></div>",
    NONE_DATA_EXAM: "<div class='zwt zwt-ks'><p>${content}</p></div>",
    NONE_DATA_COURSE: "<div class='zwt zwt-kc'><p>${content}</p></div>",
    NONE_DATA_COLLECT: "<div class='zwt zwt-sc'><p>${content}</p></div>",
    NONE_DATA_ROLE: "<div class='zwt zwt-myjs'><p>${content}</p></div>",
    NONE_DATA_REPORT: "<div class='zwt zwt-jjz'><p>${content}</p></div>",
    NONE_DATA_QUESTIONREPORT: "<div class='zwt zwt-no-wrong-Qreports'><p>${content}</p></div>",
    NONE_DATA_QUESTIONREPORT_OK: "<div class='zwt zwt-ner'><p>${content}</p></div>",
    NONE_DATA_QX: "<div class='zwt zwt-qx'><p>${content}</p></div>",
    NONE_DATA_CONTENT: "<div class='zwt text no-padding'><p>${content}</p></div>",
    LOADING_LABEL: "<div class='spiner-example'><div class='sk-spinner sk-spinner-wave'><div class='sk-rect1'></div>&nbsp;<div class='sk-rect2'></div>&nbsp;<div class='sk-rect3'></div>&nbsp;<div class='sk-rect4'></div>&nbsp;<div class='sk-rect5'></div></div></div>"
};

Label.prototype.init = function (labelType) {
    var label = $(this.store[labelType]).clone();
    if (!label){
        alert("error... labelType missed");
    }
    return label;
};

Label.prototype.contentsVertical = function () {
};
