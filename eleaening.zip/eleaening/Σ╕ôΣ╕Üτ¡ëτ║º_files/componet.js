var redPoint;
if ("undefined" != typeof getParamUrl) {
    redPoint = new Vue({
        el: '#index_train',
        data: {
            unread: 0
        }
    });
    $.ajax({
        url: getParamUrl.getUnreadNotice,
        type: "post",
        dataType: "json",
        success: function (obj) {
            redPoint.unread = obj.unreadCount
        }
    });
}
//感叹号
Vue.component('gth', {
    props: ['gthtypetodo'],
    template: '<i class="fa fa-exclamation-circle hide"  v-if="gthtypetodo == 0"></i>' +
    '<i class="fa fa-exclamation-circle text-warning" title="本场考试，有考生异常行为"  v-else-if="gthtypetodo == 1"></i>' +
    '<i class="fa fa-exclamation-circle text-muted" v-else></i>'
});
//事务消息
var tranInfo = '<div class="tran-info">\
                      <i class="fa fa-question-circle cs-p f18 pull-right" @click="show=true"></i>\
                      <div class="alert-box" v-show="show">\
                        <i class="fa fa-times f14  cs-p pull-right" @click="show=false"></i>\
                          <p class="m-b-xs f12" v-for="ul in text">{{ul}}</p>\
                      </div>\
                  </div>';
Vue.component('tran-info', {
    template: tranInfo,
    props:['text'],
    data: function () {
        return {
            show: false
        }
    }
});

