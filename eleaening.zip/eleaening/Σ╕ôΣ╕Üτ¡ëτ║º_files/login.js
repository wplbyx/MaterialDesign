/* 
 * 登录处理器.
 * 
 * 基于jquery
 */
var EasyxueGuard = function (contextPath) {
    //修正根服务路径.
    if (contextPath == null || contextPath == "/") {
        contextPath = "";
    }

//    var url={
//        login: "/loginCompany"
//    };


    /**
     * 密码登录.
     * @param {string} username
     * @param {string} password
     * @param {boolean} rememberMe
     * @param {string} companyFlag
     * @param {function} success
     * @param {function} failed
     * @returns {undefined}
     */
    this.login = function (username, password, rememberMe, companyFlag, success, failed) {

        $.ajax({
            type: "POST",
            url: contextPath + "/api/login",
//            url: contextPath + "/loginV2Controller",
            data: {
                username: username,
                password: password,
                rememberMe: rememberMe
            },
            dataType: "json",
            success: function (data, textStatus, jqXHR) {
                if (data.status == 200) {
                    //登录成功.
                    success(data, textStatus, jqXHR);
                } else {
                    //登录失败
                    failed(data, textStatus, jqXHR, null);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                failed(null, textStatus, jqXHR, errorThrown);

            }
        });
    }
    /**
     * 登出操作.
     * @param {function (jqXHR, textStatus, errorThrown)} callback
     */
    this.logout = function (callback) {

        $.ajax({
            type: "POST",
            url: contextPath + "/api/my/logout",
//            url: contextPath + "/loginV2Controller",
            dataType: "json",
            success: function (result, textStatus, jqXHR) {
                callback(textStatus, jqXHR);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                failed(textStatus, jqXHR, errorThrown);
            }
        });
    }

    /**
     * 切换企业.
     * @param {type} companyId
     * @param {type} comDomain
     * @param {type} failed
     * @returns {undefined}
     */
    this.switchCompany = function (companyId, comDomain, failed) {
        this.chioceCompany(companyId, comDomain, function () {
            window.location.href = contextPath + "/" + comDomain + "/com/ctrl/index";
        }, failed);
    }
    /**
     * 切换企业.
     * @param {type} companyId
     * @param {type} comDomain
     * @param {type} success
     * @param {type} failed
     * @returns {undefined}
     */
    this.chioceCompany = function (companyId, comDomain, success, failed) {
        $.ajax({
            type: "POST",
            url: contextPath + "/api/my/company/switchCompany",
            data: {
                companyId: companyId
            },
            dataType: "json",
            success: function (result) {
                if (result.status == 200) { // 登录成功
                    if (comDomain == null) {
                        comDomain = companyId;
                    }
                    success(companyId, comDomain);
//                    window.location.href = contextPath + "/" + comDomain + "/com/ctrl/index";
                } else {
                    failed(result);
                }
            },
            error: function (data) {
                failed(data);
            }
        });
    }

    /**
     * 取得当前的Token.
     * 
     * @param {type} success
     * @param {type} failed
     * @returns {undefined}
     */
    this.getLoginToken = function (success, failed) {
        $.ajax({
            type: "POST",
            url: contextPath + "/api/login/token",
//            url: contextPath + "/loginV2Controller",
            dataType: "json",
            success: function (result, textStatus, jqXHR) {
                if (result.status == 200) {
                    //登录成功.
                    var token = result.data.token;
                    if (token == undefined) {
                        token = null;
                    }
                    success(token);
                } else {
                    //登录失败
                    failed(result, textStatus, jqXHR, null);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                failed(null, textStatus, jqXHR, errorThrown);

            }
        });
    }

    /**
     * 手机扫码登录管理器.
     * 
     * @param {function(url,qrToken)} afterGetQr
     * @param {function(status)} afterUpdateQr
     * @param {function(loginToken)} loginSuccess
     * @returns {undefined}
     */
    this.createAppLoginManager = function (afterGetQr, afterUpdateQr, loginSuccess) {
        return new AppLoginManager(afterGetQr, afterUpdateQr, loginSuccess);
    }
    var AppLoginManager = function (afterGetQr, afterUpdateQr, loginSuccess) {

        var timer = null;
        /**
         * 取得二维码.
         * @param {type} $img 显示二维码的图片位置.
         * @returns {undefined}
         */
        function getQrCodeAjax(success) {
            $.ajax({
                url: contextPath + "/getMobileSweepQrCode",
                type: "POST",
                dataType: "json",
                success: function (data) {
                    success(data.tempQrCodeImageUrl, data.atToken);
                }
            });
        }

        this.start = function () {
            stopT();
            getQrCodeAjax(function (url, qrToken) {
                if (timer != null) {
                    timer.stop();
                }
                timer = new Timer(qrToken);
                timer.start();
                afterGetQr(url, qrToken);
            });
        }

        /**
         * stopTimer
         */
        function stopT() {
            if (timer != null) {
                timer.stop();
                timer = null;
            }
        }

        this.stop = stopT;

        /**
         * 刷新定时器.
         */
        function Timer(atToken) {
            var dur;
            var doing = false;
//            var atToke;
            /**
             * 启动二维码更新定时器.定时刷新二维码.
             * @param {type} atToken
             * @returns {undefined}
             */
            this.start = function () {
                stopTimer(atToken);
                /**
                 * 刷新二维码登录状态.
                 */
                function getMobileSweepQrCodeStatus(atToken) {
                    if (!doing) {
                        doing = true;
                        $.ajax({
                            url: contextPath + "/api/login/withMobileQR",
                            type: "post",
                            data: {atToken: atToken},
                            dataType: "json",
                            beforeSend: function (xhr) {},
                            complete: function (jqXHR, textStatus) {
                                doing = false;
                            },
                            success: function (result) {
                                if (result) {
                                    switch (result.status) {
                                        case 1: //已扫码,未确认.
//                                        if (!$("#dv_showSweepLogin").is(":hidden")) {
//                                            $("#dv_showSweepLogin").hide();
//                                            $("#dv_prepareSweepLogin").show();
//                                        }
                                            afterUpdateQr(result.status);
                                            break;
                                        case 200://已确认.
                                            timer.stop();
                                            var token = result.data.token;
                                            loginSuccess(token);
                                            afterUpdateQr(result.status);
                                            break;
                                        default:
                                            switch (result.errorCode) {
                                                case 550://超时.
                                                    //停止自动刷新.
                                                    timer.stop();
                                                    break;

                                                default://未知情况,刷新二维码.
                                                    break;
                                            }
                                            afterUpdateQr(result.errorCode);
                                            break;
                                    }
                                }
                            },
                            cache: false
                        });
                    }
                }

                //启动与服务器对时
                dur = window.setInterval(function () {
                    getMobileSweepQrCodeStatus(atToken);
                }, 1500);
            }

            /**
             * 停止二维码刷新定时器.
             */
            function stopTimer(atToken) {
                if (dur && dur != null) {
                    window.clearInterval(dur);
                    dur = null;
                }
            }

            this.stop = stopTimer;

        }

    }

}

EasyxueGuard.loginErrorCode = {
    /**
     * 密码错误.
     */
    PASSWORD_ERROR: 400,
    /**
     * 用户不存在.
     */
    NO_USER: 410,
    /**
     * 用户被冻结.
     */
    FROZEN_USER: 420,
    /**
     * 未知的错误.
     */
    UNKNOWN: 9999
}





