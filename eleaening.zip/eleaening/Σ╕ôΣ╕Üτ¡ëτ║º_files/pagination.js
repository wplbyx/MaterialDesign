

    var Pagination = function(elementId,ajaxFunction,totalCount,pageSize,pageNum){
	this.$element = $("#"+elementId);
	this.$elementId=elementId;
	this.totalCount = totalCount;
	this.pageCount=Math.ceil(totalCount/pageSize);
	this.pageNumber=pageNum;
	if(pageNum>=this.pageCount)
	{
	this.pageNumber=this.pageCount;
	}
	this.ajaxFunction=ajaxFunction;
	this.paginationDeep = $("#"+elementId).attr("deep");
	this.size=$("#"+elementId).attr("size");
	this.ckFlag = $("#"+elementId).attr("ckFlag");
	if(this.ckFlag==null)
	{
	this.ckFlag = $("#"+elementId+"page").attr("ckFlag");
	}
	this.$finalHtml;
	if(this.paginationDeep==null||this.paginationDeep==""||+this.paginationDeep<=0)
	{
	    this.paginationDeep=3;
	}
	if(this.size==null||this.size==""||+this.size>3||+this.size<0)
	{
	    this.size=2;
	}
	var tempFlag = ""
	if(this.ckFlag!=null&&this.ckFlag!="")
	{
		tempFlag = "ckFlag='"+this.ckFlag+"'";
	}
	this.oldHtml="<p id='"+elementId+"' deep='"+this.paginationDeep+"' size='"+this.size+"' "+tempFlag+"></p>"//$("<div></div>").append($(this.$element).clone()).html();
	this.init(this.pageCount, this.pageNumber, this.ajaxFunction, this.size,this.ckFlag);
	this.replaceBackDom();
    };  
    Pagination.prototype={
	    constructor:Pagination,
	    init:function(pageCount,pageNum,ajaxFunction,size,ckFlag){
		var tempHtml = this.oldHtml;
		if(pageCount==0)
		{
		this.$finalHtml=null;
		return;
		}
		this.ensureSize(+size);
		var html="";
		 this.$finalHtml = $("<div></div>").addClass("pagination pagination-right "+this.$cssSize).attr("id",this.$elementId+"page");
		 this.$finalHtml.attr("ckFlag",ckFlag);
		 this.ulDom=$("<ul></ul>");
		 if(this.size>1)
		 {
			 var totalCount = $("<li></li>").appendTo(this.ulDom);
			 var $a = $("<a></a>").text("共计有"+this.totalCount+"条记录");
			 if(ckFlag)
			 {
				 var option1=$("<option>10</option>");
				 if($.cookie(ckFlag)*1==10)
				 {
					 option1=$("<option selected>10</option>");
				 }
				 var option2=$("<option>20</option>");
				 if($.cookie(ckFlag)*1==20)
				 {
					 option2=$("<option selected>20</option>");
				 }
				 
				 var option3=$("<option>50</option>");
				 if($.cookie(ckFlag)*1==50)
				 {
					 option3=$("<option selected>50</option>");
				 }
				 
				 var option4=$("<option>80</option>");
				 if($.cookie(ckFlag)*1==80)
				 {
					 option4=$("<option selected>80</option>");
				 }
				 
				 var option5=$("<option>100</option>");
				 if($.cookie(ckFlag)*1==100)
				 {
					 option5=$("<option selected>100</option>");
				 }
				 
				 var select  = $("<select style='width:80px;height:18px;margin:-1px 5px 0px 5px;padding:0px 6px'></select>");
				 select.append(option1);
				 select.append(option2);
				 select.append(option3);
				 select.append(option4);
				 select.append(option5);
				 select.change(function(event){
					 var ddd =$(this).val(); 
					 $.cookie(ckFlag, ddd,{expires:30});
					 var dom = $(event.target);
					    $(dom).parents("div.pagination").after(tempHtml);
					    $(dom).parents("div.pagination").remove();
					 ajaxFunction(1);
				 });
				 var selectLi = $("<li></li>");
				 $a.append(",当前页有").append(select).append("条记录");
			 }
			 $a.appendTo(totalCount);
		 }
		 

		 
		 var preLiDom = $("<li></li>").appendTo(this.ulDom);
		if(pageNum-1 <= 0){
		    $("<a>&lt;</a>").attr("href","javascript:void(0)").click(function(event){
		    var dom = $(event.target);
		    $(dom).parents("div.pagination").after(tempHtml);
		    $(dom).parents("div.pagination").remove();
		    ajaxFunction(1);
		}).appendTo(preLiDom)
		}else{
		    $("<a>&lt;</a>").attr("href","javascript:void(0)").click(function(event){
			    var dom = $(event.target);
			    $(dom).parents("div.pagination").after(tempHtml);
			    $(dom).parents("div.pagination").remove();
			    ajaxFunction(pageNum-1);
			}).appendTo(preLiDom)
		}
		
		this.divDom=$("<div></div>")
		this.pageIcon(+pageCount,+pageNum,+pageNum,+this.paginationDeep,ajaxFunction);
		$(this.divDom).find("li").appendTo(this.ulDom);
		var nextLiDom = $("<li></li>").appendTo(this.ulDom);
		if(pageNum+1 >= pageCount ){
		    $("<a>&gt;</a>").attr("href","javascript:void(0)").click(function(event){
			    var dom = $(event.target);
			    $(dom).parents("div.pagination").after(tempHtml);
			    $(dom).parents("div.pagination").remove();
			    ajaxFunction(pageCount);
			}).appendTo(nextLiDom)
		}else{
		    $("<a>&gt;</a>").attr("href","javascript:void(0)").click(function(event){
			    var dom = $(event.target);
			    $(dom).parents("div.pagination").after(tempHtml);
			    $(dom).parents("div.pagination").remove();
			    ajaxFunction(pageNum+1);
			}).appendTo(nextLiDom)
		}
		this.ulDom.appendTo(this.$finalHtml)
	    },
	    pageIcon:function(total, page, pageNum, size,ajaxFunction) {
		var tempHtml = this.oldHtml;
		if(pageNum==page)
		{
		    var liDom = $("<li></li>").addClass("active");
		    $("<a>"+pageNum+"</a>").appendTo(liDom);
		    this.divDom.append(liDom);
		    this.pageIcon(total,page,pageNum-1,size+(total+1-page<=size?size+page-total-1:0)-1,ajaxFunction);
		    this.pageIcon(total,page,pageNum+1,size-1+(page+1-size<=0?size-page:0),ajaxFunction);
		}
		if(pageNum<page&&pageNum>0&&size>0)
		{
		    var liDom = $("<li></li>");
		    $("<a>"+pageNum+"</a>").click(function(event){
			 var dom = $(event.target);
			    $(dom).parents("div.pagination").after(tempHtml);
			    $(dom).parents("div.pagination").remove();
			    ajaxFunction(pageNum);
		    }).attr("href","javascript:void(0)").appendTo(liDom);
		    this.divDom.prepend(liDom);
		    this.pageIcon(total,page,pageNum-1,size-1,ajaxFunction);
		}
		if(pageNum>page&&pageNum<total+1&&size>0)
		{
		    var liDom = $("<li></li>");
		    $("<a>"+pageNum+"</a>").click(function(event){
			 var dom = $(event.target);
			    $(dom).parents("div.pagination").after(tempHtml);
			    $(dom).parents("div.pagination").remove();
			    ajaxFunction(pageNum);
		    }).attr("href","javascript:void(0)").appendTo(liDom);
		    this.divDom.append(liDom);
		    this.pageIcon(total,page,pageNum+1,size-1,ajaxFunction);
		}
	    },
	    ensureSize:function(size){
		this.$cssSize="";
		switch (size) {
		case 0:
		    this.$cssSize="pagination-mini";
		    break;
		case 1:
		    this.$cssSize="pagination-small";
		    break;
		case 2:
		    this.$cssSize="";
		    break;
		default:
		    this.$cssSize="pagination-large";
		    break;
		}
	    },
	    replaceBackDom:function()
	    {
	    	if(this.$finalHtml==null||this.$finalHtml=="")
	    	{
	    		$("#"+this.$elementId+"page").after(this.oldHtml);
	    		$("#"+this.$elementId+"page").remove();
	    	}
	    	else if(this.$element.attr("id"))
	    	{
				this.$element.after(this.$finalHtml);
				this.$element.remove();
	    	}
	    	else
	    	{
	    		var reDiv = this.$finalHtml.children();
	    		$("#"+this.$elementId+"page").html(reDiv);
	    	}
	    }
    }
