var PaginationPageDiv = function (elementId, ajaxFunction, pagination, startZero) {
    //startZero表示从0开始，传true
    var pageIndex = 0;
    if (startZero) {
        pageIndex = 1;
    }
    this.$element = $("#" + elementId);
    this.$elementId = elementId;
    this.totalCount = pagination.totalCount;
    this.pageCount = Math.ceil(pagination.totalCount / pagination.pageSize);
    this.pageNumber = pagination.pageNumber+ pageIndex;
    this.pageSize = pagination.pageSize;
    if (pagination.pageNumber >= this.pageCount) {
        this.pageNumber = this.pageCount;
    }
    this.ajaxFunction = ajaxFunction;
    this.paginationDeep = $("#" + elementId).attr("deep");
    this.size = $("#" + elementId).attr("size");
    this.ckFlag = $("#" + elementId).attr("ckFlag");
    if (this.ckFlag == null) {
        this.ckFlag = $("#" + elementId + "page").attr("ckFlag");
    }

    this.$finalHtml;
    if (this.paginationDeep == null || this.paginationDeep == "" || +this.paginationDeep <= 0) {
        this.paginationDeep = 3;
    }
    if (this.size == null || this.size == "" || +this.size > 3 || +this.size < 0) {
        this.size = 2;
    }
    var tempFlag = "";
    if (this.ckFlag != null && this.ckFlag != "") {
        tempFlag = "ckFlag='" + this.ckFlag + "'";
    }
    this.oldHtml = "<p id='" + elementId + "' class='otherheight' deep='" + this.paginationDeep + "' size='" + this.size + "' " + tempFlag + "></p>";//$("<div></div>").append($(this.$element).clone()).html();
    this.init(this.pageCount, this.pageNumber, this.ajaxFunction, this.size, this.ckFlag,pageIndex);
    this.replaceBackDom();
};

PaginationPageDiv.prototype = {
    constructor: Pagination,
    init: function (pageCount, pageNum, ajaxFunction, size, ckFlag, pageIndex) {
        var tempHtml = this.oldHtml;
        if (pageCount == 0) {
            this.$finalHtml = null;
            return;
        }
        this.ensureSize(+size);
        var html = "";
        this.$finalHtml = $("<div></div>").addClass("clearfix" + this.$cssSize).attr("id", this.$elementId + "page");
        this.$finalHtml.attr("ckFlag", ckFlag);
        this.ulDom = $("<ul class='pagination pull-right no-margins' style='margin-top:10px!important;'></ul>");
        if (this.size > 1) {
            var totalCount = $("<li class='hidden-xs hidden-sm'></li>").appendTo(this.ulDom);
            var $a = $("<a></a>").text("共" + this.totalCount + "条");
            if (ckFlag) {
                var option0 = $("<option>5</option>");
                var option1 = $("<option>10</option>");
                var option2 = $("<option>20</option>");
                var option3 = $("<option>50</option>");
                var option4 = $("<option>80</option>");
                var option5 = $("<option>100</option>");
                if ($.cookie(ckFlag) * 1 == 5 || this.pageSize == 5) {
                    option0 = $(option0).attr("selected","selected");
                }
                if ($.cookie(ckFlag) * 1 == 10||$.cookie(ckFlag)==undefined) {
                    option1 = $(option1).attr("selected","selected");
                }
                if ($.cookie(ckFlag) * 1 == 20) {
                    option2 = $(option2).attr("selected","selected");
                }
                if ($.cookie(ckFlag) * 1 == 50) {
                    option3 = $(option3).attr("selected","selected");
                }
                if ($.cookie(ckFlag) * 1 == 80) {
                    option4 = $(option4).attr("selected","selected");
                }
                if ($.cookie(ckFlag) * 1 == 100) {
                    option5 = $(option5).attr("selected","selected");
                }

                var select = $("<select style='display: inline-block;height: 20px;margin: -4px 2px 0;padding: 0px 3px;vertical-align: middle;width: 60px;'></select>");
                select.append(option0);
                select.append(option1);
                select.append(option2);
                select.append(option3);
                select.append(option4);
                select.append(option5);
                select.change(function (event) {
                    var ddd = $(this).val();
                    $.cookie(ckFlag, ddd, {expires: 30});
                    var dom = $(event.target);
                    $(dom).parents("div.pagination").after(tempHtml);
                    $(dom).parents("div.pagination").remove();
                    //ajaxFunction(1);
                    if (pageIndex == 1) {
                        ajaxFunction(0);
                    } else {
                        ajaxFunction(1);
                    }
                });
                var selectLi = $("<li></li>");
                $a.append(",每页").append(select).append("条");
            }
            $a.appendTo(totalCount);
        }


        var preLiDom = $("<li></li>").appendTo(this.ulDom);
        if (pageNum - 1 <= 0) {
            $("<a disabled='disabled'>&lt;</a>").attr("href", "javascript:void(0)").appendTo(preLiDom);
        } else {
            $("<a>&lt;</a>").attr("href", "javascript:void(0)").click(function (event) {
                var dom = $(event.target);
                $(dom).parents("div.pagination").after(tempHtml);
                $(dom).parents("div.pagination").remove();
                //ajaxFunction(pageNum - 1);
                ajaxFunction(pageNum - pageIndex - 1);
            }).appendTo(preLiDom);
        }

        this.divDom = $("<div></div>");
        this.pageIcon(+pageCount, +pageNum, +pageNum, +this.paginationDeep, ajaxFunction, pageIndex);
        $(this.divDom).find("li").appendTo(this.ulDom);
        var nextLiDom = $("<li></li>").appendTo(this.ulDom);
        if (pageNum + 1 > pageCount) {
            $("<a disabled='disabled'>&gt;</a>").attr("href", "javascript:void(0)").appendTo(nextLiDom);
        } else {
            $("<a>&gt;</a>").attr("href", "javascript:void(0)").click(function (event) {
                var dom = $(event.target);
                $(dom).parents("div.pagination").after(tempHtml);
                $(dom).parents("div.pagination").remove();
                //ajaxFunction(pageNum + 1);
                ajaxFunction(pageNum - pageIndex + 1);
            }).appendTo(nextLiDom);
        }
        
		 var lastLiDom = $("<li></li>").appendTo(this.ulDom);
		 var lastaDom = $("<a></a>").appendTo(lastLiDom);
		 var selectPage  = $("<select style='display: inline-block;height: 20px;margin: -4px 2px 0;padding: 0px 3px;vertical-align: middle;width: 60px;'></select>");
		 var optionDom = '';
		 for(var i=1 ; i<= pageCount ; i++){
			 if( i== pageNum){
				 optionDom += "<option value="+ i +" selected>"+ i +"</option>";
			 }else{
				 optionDom += "<option value="+ i +">"+ i +"</option>";
			 }
		 }
		 selectPage.append(optionDom);
		 selectPage.change(function(event){
			var page =$(this).val(); 
		    var dom = $(event.target);
		    $(dom).parents("div.pagination").after(tempHtml);
		    $(dom).parents("div.pagination").remove();
		    //ajaxFunction(page);
            ajaxFunction(page - pageIndex);
		 });
		 lastaDom.append("跳转至第").append(selectPage).append("页");
        
        this.ulDom.appendTo(this.$finalHtml);
    },
    pageIcon: function (total, page, pageNum, size, ajaxFunction ,pageIndex) {
        var tempHtml = this.oldHtml;
        if (pageNum == page) {
            var liDom = $("<li></li>").addClass("active");
            $("<a>" + pageNum + "</a>").appendTo(liDom);
            this.divDom.append(liDom);
            this.pageIcon(total, page, pageNum - 1, size + (total + 1 - page <= size ? size + page - total - 1 : 0) - 1, ajaxFunction, pageIndex);
            this.pageIcon(total, page, pageNum + 1, size - 1 + (page + 1 - size <= 0 ? size - page : 0), ajaxFunction, pageIndex);
        }
        if (pageNum < page && pageNum > 0 && size > 0) {
            var liDom = $("<li></li>");
            $("<a>" + pageNum + "</a>").click(function (event) {
                var dom = $(event.target);
                $(dom).parents("div.pagination").after(tempHtml);
                $(dom).parents("div.pagination").remove();
                //ajaxFunction(pageNum);
                ajaxFunction(pageNum - pageIndex);
            }).attr("href", "javascript:void(0)").appendTo(liDom);
            this.divDom.prepend(liDom);
            this.pageIcon(total, page, pageNum - 1, size - 1, ajaxFunction,pageIndex);
        }
        if (pageNum > page && pageNum < total + 1 && size > 0) {
            var liDom = $("<li></li>");
            $("<a>" + pageNum + "</a>").click(function (event) {
                var dom = $(event.target);
                $(dom).parents("div.pagination").after(tempHtml);
                $(dom).parents("div.pagination").remove();
                ajaxFunction(pageNum - pageIndex);
            }).attr("href", "javascript:void(0)").appendTo(liDom);
            this.divDom.append(liDom);
            this.pageIcon(total, page, pageNum + 1, size - 1, ajaxFunction,pageIndex);
        }
    },
    ensureSize: function (size) {
        this.$cssSize = "";
        switch (size) {
            case 0:
                this.$cssSize = "pagination-mini";
                break;
            case 1:
                this.$cssSize = "pagination-small";
                break;
            case 2:
                this.$cssSize = "";
                break;
            default:
                this.$cssSize = "pagination-large";
                break;
        }
    },
    replaceBackDom: function () {
        if (this.$finalHtml == null || this.$finalHtml == "") {
            $("#" + this.$elementId + "page").after(this.oldHtml);
            $("#" + this.$elementId + "page").remove();
        }
        else if (this.$element.attr("id")) {
            this.$element.after(this.$finalHtml);
            this.$element.remove();
        }
        else {
            var reDiv = this.$finalHtml.children();
            $("#" + this.$elementId + "page").html(reDiv);
        }
    }
};