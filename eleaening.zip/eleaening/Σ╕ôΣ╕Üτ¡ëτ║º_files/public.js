function isEmpty(str) {
	if (str == null || str == undefined || str == "") {
		return '暂无';
	} else {
		return str;
	}
}

function formatDate(times) {
	var now = new Date();// 当前时间
	var date = now.getTime();
	var second = date - times;
	secondold = second / 1000;
	second = second / 1000;
	// echo $second;exit();

	var day = Math.floor(second / (3600 * 24));
	second = second % (3600 * 24);// 除去整天之后剩余的时间
	var hour = Math.floor(second / 3600);
	second = second % 3600;// 除去整小时之后剩余的时间
	var minute = Math.floor(second / 60);
	second = second % 60;// 除去整分钟之后剩余的时间
	var str = "";
	if (day) {
		str = day + "天前";
		if (day > 1) {
			str = new Date(times).Format("MM月dd日 hh:mm");
		}
	} else if (hour) {
		str = hour + "小时前";
	} else if (minute) {
		str = minute + "分钟前";
	} else {
		str = "刚刚";
	}
	if (secondold < 60) {
		str = "刚刚";
	}
	return str;
}

(function($) {
	$.fn.insertText = function(text) {
		this.each(function() {
			if (this.tagName !== 'INPUT' && this.tagName !== 'TEXTAREA') {
				return;
			}
			if (document.selection) {
				this.focus();
				var cr = document.selection.createRange();
				cr.text = text;
				cr.collapse();
				cr.select();
			} else if (this.selectionStart || this.selectionStart == '0') {
				var start = this.selectionStart, end = this.selectionEnd;
				this.value = this.value.substring(0, start) + text
						+ this.value.substring(end, this.value.length);
				this.selectionStart = this.selectionEnd = start + text.length;
			} else {
				this.value += text;
			}
		});
		return this;
	};
})(jQuery);

Date.prototype.Format = function(fmt) { // author: meizz
	var o = {
		"M+" : this.getMonth() + 1, // 月份
		"d+" : this.getDate(), // 日
		"h+" : this.getHours(), // 小时
		"m+" : this.getMinutes(), // 分
		"s+" : this.getSeconds(), // 秒
		"q+" : Math.floor((this.getMonth() + 3) / 3), // 季度
		"S" : this.getMilliseconds()
	// 毫秒
	};
	 var week = {         
	    "0" : "日",
	    "1" : "一",
	    "2" : "二",
	    "3" : "三",
	    "4" : "四",
	    "5" : "五",
	    "6" : "六"
    };
	if (/(y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "")
				.substr(4 - RegExp.$1.length));
	if(/(E+)/.test(fmt)){//EEE  星期二   /   EE周二     E 二
        fmt=fmt.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "星期" : "周") : "")+week[this.getDay()+""]);         
    }     
	for ( var k in o)
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k])
					: (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
};

String.prototype.replaceAll = function (reallyDo, replaceWith, ignoreCase) {
    if (!RegExp.prototype.isPrototypeOf(reallyDo)) {
        return this.replace(new RegExp(reallyDo, (ignoreCase ? "gi" : "g")), replaceWith);
    } else {
        return this.replace(reallyDo, replaceWith);
    }
};

String.prototype.realLength = function () {
	var len = 0;
	if (this.match(/[^ -~]/g) == null) {
		len = this.length;
	}else{
		len = this.length + this.match(/[^ -~]/g).length;
	}
	return len;
};

String.prototype.substringToLength = function (length) {
	if(this.length > length){
		return this.substring(0,length)+"...";
	}else{
		return this;
	}
}
;

/**
 * 替换字符串（替换大于号和小于号变成）
 */
String.prototype.getContent = function () {
	var content = '';
	if(this && this != ''){
		content = this.replaceAll('<','&lt;');
		content = content.replaceAll('>','&gt;');
	}
	return content;
};

/**
 * 比较字符串
 */
String.prototype.equals = function(obj) {
	if (this == obj) {
		return true;
	} else {
		return false;
	}
};

/**
 * 忽略大小比较字符串
 */
String.prototype.ignoreEquals = function(obj) {
	if (this.toUpperCase() == obj.toUpperCase()) {
		return true;
	} else {
		return false;
	}
};

function strlength(val) {
	var len = 0;
	for (var i = 0; i < val.length; i++) {
		if (val[i].match(/[^\x00-\xff]/ig) != null) {
			len++;
		} else {
			len = len + 0.5;
		}
	}
	return Math.floor(len);
}

function getCursorPosition(textarea) {
	var rangeData = {
		text : "",
		start : 0,
		end : 0
	};
	textarea.focus();
	if (textarea.setSelectionRange) { // W3C
		rangeData.start = textarea.selectionStart;
		rangeData.end = textarea.selectionEnd;
		rangeData.text = (rangeData.start != rangeData.end) ? textarea.value
				.substring(rangeData.start, rangeData.end) : "";
	} else if (document.selection) { // IE
		var i;
		var oS = document.selection.createRange();
		// Don't: oR = textarea.createTextRange()
		var oR = document.body.createTextRange();
		oR.moveToElementText(textarea);

		rangeData.text = oS.text;
		rangeData.bookmark = oS.getBookmark();

		// object.moveStart(sUnit [, iCount])
		// Return Value: Integer that returns the number of units moved.
		for (i = 0; oR.compareEndPoints('StartToStart', oS) < 0
				&& oS.moveStart("character", -1) !== 0; i++) {
			// Why? You can alert(textarea.value.length)
			if (textarea.value != null && textarea.value.charAt(i) == '\n') {
				i++;
			}
		}
		rangeData.start = i;
		rangeData.end = rangeData.text.length + rangeData.start;
	}
	return rangeData;
}

String.prototype.trim = function() {
	return this.replace(/(^\s*)(\s*$)/g, "");
};

// 是否为空
function isNull(v) {
	if (v == undefined || v == null || v == "") {
		return true;
	}
	return false;
}

// 获取用时
function getUseTime(startTime, endTime) {
	var useTime = "";
	if (isNull(startTime)) {
		useTime = "0分钟";
	} else if (isNull(endTime)) {
		useTime = timeDiff(startTime, (new Date()).getTime());
	} else {
		useTime = timeDiff(startTime, endTime);
	}
	return useTime;
}

function timeDiff(startTime, endTime) {
	var sTime = Date.parse(new Date(startTime));
	var eTime = Date.parse(new Date(endTime));
	var dif = Math.abs(eTime.getTime() - sTime.getTime());
	var days = Math.floor(dif / (24 * 3600 * 1000));

	var leave1 = dif % (24 * 3600 * 1000); // 计算天数后剩余的毫秒数
	var hours = Math.floor(leave1 / (3600 * 1000)); // 计算相差分钟数
	var leave2 = leave1 % (3600 * 1000); // 计算小时数后剩余的毫秒数
	var minutes = Math.floor(leave2 / (60 * 1000));// 计算相差秒数
	var leave3 = leave2 % (60 * 1000); // 计算分钟数后剩余的毫秒数
	var seconds = Math.round(leave3 / 1000);

	var useTime = "";
	if (days > 0) {
		useTime = days + " 天 " + hours + " 小时 " + minutes + " 分钟 " + seconds
				+ " 秒";
	} else if (hours > 0) {
		useTime = hours + " 小时 " + minutes + " 分钟 " + seconds + " 秒";
	} else if (minutes > 0) {
		useTime = minutes + " 分钟 " + seconds + " 秒";
	} else {
		if (seconds === 0) {
			seconds = 1;
		}
		useTime = seconds + " 秒";
	}
	return useTime;
}
$(".form_meridian_datetime").click(function() {
	var isonfocus = $(this).find("input").is(":focus");
	if (isonfocus) {
		$(this).find("input").blur();
	}
});
$(".form_datetime").click(function() {
	var isonfocus = $(this).find("input").is(":focus");
	if (isonfocus) {
		$(this).find("input").blur();
	}
});

function contentsVertical() {
	var topheight = $(".contents-vertical").offset().top;
	var bodyheight = document.documentElement.clientHeight;
	var footer = $(".footer").outerHeight(true);
	var contentsHeight = $(".contents-vertical").outerHeight(true);
	var vertical = (bodyheight - footer - topheight - contentsHeight) / 2;
	if ($(".contents-vertical").length != 0) {
		if (vertical > 0) {
			$(".xss").css({
				"margin-bottom" : vertical
			});
			$(".xss").css({
				"margin-top" : vertical
			});
		} else {
			$(".xss").css({
				"margin-bottom" : 0
			});
			$(".xss").css({
				"margin-top" : 0
			});
		}

	}
}

// 根据ID 获取code
var ID_CODE = {};
// 根据code 获取父级code
var CODE_PARENT = {};
// 根据code 获取名称
var CODE_NAME = {};

var DepInfo_function = function() {
	return {
		initDepList : function(depList) {
			$.each(depList, function(i, dep) {
				CODE_PARENT[dep.code] = dep.parentId;
				ID_CODE[dep.id] = dep.code;
				CODE_NAME[dep.code] = dep.depName;
			});
		},
		getDepInfoById : function(depId) {
			if (depId == null || depId == "") {
				return "";
			}
			var depName = "";
			var code = ID_CODE[depId];
			while (code != null && code.length > 0 && code != 0) {
				if (depName != "") {
					depName = CODE_NAME[code] + " > " + depName;
				} else {
					depName = CODE_NAME[code];
				}
				var parentCode = CODE_PARENT[code];
				if(parentCode==code){
					depName = "";
					break;
				}else{
					code = parentCode;
				}
			}
			return depName;
		},
		getDepInfoByCode : function(code) {
			if (code == null || code == "") {
				return "";
			}
			var depName = "";
			while (code != null && code.length > 0 && code != 0) {
				if (depName != "") {
					depName = CODE_NAME[code] + " > " + depName;
				} else {
					depName = CODE_NAME[code];
				}
				var parentCode = CODE_PARENT[code];
				if(parentCode==code){
					depName = "";
					break;
				}else{
					code = parentCode;
				}
			}
			return depName;
		},
		getOnlyDepNameById : function(depId) {
			if (depId == null || depId == "") {
				return "";
			}
			var code = ID_CODE[depId];
			if(!code || code == ""){
				return "";
			}
			var depName = CODE_NAME[code];
			if(!depName){
				depName = "";
			}
			return depName;
		}
	};
}();

/**
 * loading Dept
 */
function loadDeptLists(url_depList) {
	$.ajax({
		url : url_depList,
		type : "post",
		async : false,
		success : function(data) {
			DepInfo_function.initDepList(eval("(" + data + ")"));
		},
		error : function(xhr, errorText) {}
	});
}

/** btn-navbar */
$('.btn-navbar').click(function() {
	var ifhas = $(this).hasClass('collapsed');
	if (ifhas) {
		$('.page-content , .header').addClass('left-225');
	} else {
		$('.page-content , .header').removeClass('left-225');
	}
});

function dateTimeFormat(dateTimeStr) {
    if (typeof dateTimeStr == "string") {
        dateTimeStr = dateTimeStr.replace(/-/g, "/");
    }
    var dateModifyTime = new Date(dateTimeStr).Format("yyyy-MM-dd hh:mm");
    return dateModifyTime;
}