$(document).ready(function () {
//     高级搜索
     $('.btn.level-top').click(function () {
     	if($(this).parents(".btn-group").length == 0){
     		var domclass = $(this).hasClass('active');
     		if (domclass) {
                 $(this).parents('.fast-search').siblings('.level-top-search').slideUp('400');
                 $(this).removeClass('active');
                 $(this).text('高级查询');
             } else {
                 $(this).parents('.fast-search').siblings('.level-top-search').slideDown('400');
                 $(this).addClass('active');
                 $(this).text('收起');
                 $(".ibox-title select,.modal-body .level-top-search select").select2();
             }
     	}
    });
    
    $(".fast-search .btn-group").on("click","a,button",function(){
     	$_dateTimeBtn = $(this).parent();
     	//判断是a标签还是button标签
     	if($(this).hasClass("file-control")){
     		if(!$(this).hasClass("active")){
         		$_dateTimeBtn.find("a").removeClass("active");
     			$(this).removeClass("active");
     			$(this).addClass("active");
     			var $_levelTopSearch = $(this).parents('.fast-search').siblings('.level-top-search');
     			var isAll = $_dateTimeBtn.find("a").eq(0).text().replaceAll(" ","") == "全部";
     			if($(this).index() < ($_dateTimeBtn.find("a").length - 1)){
     				$_levelTopSearch.hide();
     				setDateTimeFactory($(this).index(), $_levelTopSearch, isAll);
     				dateTimeChangeEvent();
     			}else{
     				$_levelTopSearch.find("input").val("");
     				$_levelTopSearch.slideDown('400');
     			}
         	}
     	}else{
     		if(!$(this).hasClass("btn-primary")){
        		$_dateTimeBtn.find(".btn-primary").addClass("btn-white");
        		$_dateTimeBtn.find("button").removeClass("btn-primary");
    			$(this).removeClass("btn-white");
    			$(this).addClass("btn-primary");
    			var $_levelTopSearch = $(this).parents('.fast-search').siblings('.level-top-search');
    			var isAll = $_dateTimeBtn.find("button").eq(0).text().replaceAll(" ","") == "全部";
    			if($(this).index() < ($_dateTimeBtn.find("button").length - 1)){
    				$_levelTopSearch.hide();
    				setDateTimeFactory($(this).index(), $_levelTopSearch, isAll);
    				dateTimeChangeEvent();
    			}else{
    				$_levelTopSearch.find("input").val("");
    				$_levelTopSearch.slideDown('400');
    			}
        	}
     	}
    });
    //左侧渲染成select2插件
    var selectsAll = $(".ibox.float-e-margins .ibox-content").find(".m-t-md,.m-t-sm,.m-b-md,.m-b-sm").find("select");
    selectsAll.select2();
    if(typeof dateTimeChangeEvent === 'function' ){
    	selectsAll.on("change",function(e){
    		dateTimeChangeEvent();
    	});
    }
});

function setDateTimeFactory(index, $_levelTopSearch, isAll){
	if(isAll){
		if(index > 0){
			index = index - 1;
		}else{
			$_levelTopSearch.find("input").val("");
			return;
		}
	}
	var nowDate = new Date(new Date().setHours(23, 59, 59, 0));
	$_levelTopSearch.find("input").eq(1).val(nowDate.Format(searchFormatDate));
	var AddDayCount = 0;
	if(index == 0){
		AddDayCount = 30;
	}else if(index == 1){
		AddDayCount = 7;
	}else if(index == 2){
		AddDayCount = 1;
	}
	nowDate.setDate(nowDate.getDate() - AddDayCount + 1);
	$_levelTopSearch.find("input").eq(0).val(new Date(nowDate.setHours(0, 0, 0, 0)).Format(searchFormatDate));
}

function setNewDateTimeFormat(dateTimeStr){
    if(typeof dateTimeStr == "string"){
        dateTimeStr = dateTimeStr.replace(/-/g,"/");
    }
    var nowYear = new Date().getFullYear();
    var endTimeYear = new Date(dateTimeStr).getFullYear();
    var dateModifyTime = "";
    if(endTimeYear == nowYear){
        //当年
        dateModifyTime = new Date(dateTimeStr).Format("MM月dd日 hh:mm");
    }else{
        dateModifyTime = new Date(dateTimeStr).Format("yyyy年MM月dd日 hh:mm");
    }
    return dateModifyTime;
}

function dateTimeFormatNew(dateTimeStr){
    if(typeof dateTimeStr == "string"){
        dateTimeStr = dateTimeStr.replace(/-/g,"/");
    }
    var nowYear = new Date().getFullYear();
    var endTimeYear = new Date(dateTimeStr).getFullYear();
    var dateModifyTime = "";
    if(endTimeYear == nowYear){
        //当年
        dateModifyTime = new Date(dateTimeStr).Format("MM-dd hh:mm");
    }else{
        dateModifyTime = new Date(dateTimeStr).Format("yyyy-MM-dd hh:mm");
    }
    return dateModifyTime;
}

$.confirm = function (options) {
    var okButtonText = "确定";
    if(options.okButtonText){
        okButtonText = options.okButtonText;
    }
    var okButtonColor = "#ec6c62";
    if(options.okButtonColor){
        okButtonColor = options.okButtonColor;
    }
    var cancelButtonText = "取消";
    if(options.cancelButtonText){
        cancelButtonText = options.cancelButtonText;
    }
    var type = "warning";
    if(options.type){
        type = options.type;
    }
    //Set to false 如果你希望当用户按下 "Confirm" 按钮后模态窗依然开启。这对于当用户按下 "Confirm" 按钮后调用了另一个 SweetAlert 的情况非常有用。
    var closeOnConfirm = true;
    if(options.closeOnConfirm != undefined){
        closeOnConfirm = options.closeOnConfirm;
    }
    swal({
        title: options.title,
        text: options.message,
        type: type,
        showCancelButton: true,
        closeOnConfirm: closeOnConfirm,
        confirmButtonText: okButtonText,
        confirmButtonColor: okButtonColor,
        cancelButtonText: cancelButtonText
    }, function(isConfirm) {
    	if(isConfirm){
    		if(options["ok"]){
    			options.ok();
    		}
    	}else{
    		if(options["cancel"]){
    			options.cancel();
    		}
    	}
    });
};

$.alert = function (options) {
    var okButtonText = "确定";
    var type = "success";
    var okButtonColor = "#ec6c62";

    if(options.okButtonText){
        okButtonText = options.okButtonText;
    }

    if(options.type){
        type = options.type;
    }

    if(options.okButtonColor){
        okButtonColor = options.okButtonColor;
    }

    var params = {
        title: options.title,
        text: options.message,
        type: type,
        showCancelButton: false,
        closeOnConfirm: true,
        confirmButtonText: okButtonText,
        confirmButtonColor: okButtonColor
    };

    if (type == "success"){
        delete params.confirmButtonColor;
    }

    if (options.timer && options.timer != 0){
        params.timer = options.timer;
    }
    swal(params, function() {
        options.ok();
    });
};

$.prompt = function (options) {
    var shortCutFunction = 'success';
    if(options && options.shortCutFunction){
        shortCutFunction = options.shortCutFunction;
    }
	var time = "1000";
	if(options && options.time){
		time = options.time;
	}
    if(typeof toastr == "object"){
    	toastr.options = {
	        closeButton: true,
	        debug: false,
	        progressBar: true,
	        preventDuplicates:true,
	        positionClass:  options.positionClass,
	        showDuration: "400",
	        hideDuration: "1000",
	        timeOut: time,
	        extendedTimeOut: "1000",
	        showEasing: "swing",
	        hideEasing: "linear",
	        showMethod: "fadeIn",
	        hideMethod: "fadeOut",
	        onclick: options.jumpPage
	    };
	    $("#" + options.toastrOptions).text("Command: toastr["+ shortCutFunction+ "](\"" + options.msg + (options.title ? "\", \"" + options.title : '')+ "\")\n\ntoastr.options = "
	        + JSON.stringify(toastr.options, null, 2)
	    );
	    var $toast = toastr[shortCutFunction](options.msg, options.title);
    }
};

(function($){
	var btnStyleAndEvent = {
		init : function(){
		},
		btnBright : function(options){
			var btnClass = "btn-danger";
			if(options && options["btnClass"]){
				btnClass = options["btnClass"];
			}
			var needDelCount = 0;
			if(options["mode"] == "i-checks"){
				needDelCount = $("#" + options["contentId"]).find("input.i-checks:checked").length;
			}else if(options["mode"] == "exam-select-radio"){
				needDelCount = $("#" + options["contentId"]).find(".exam-select-radio.on").length;
			}
			var $_this = $(this);
			if(needDelCount > 0){
				$_this.removeClass("btn-muted").addClass(btnClass);
				//$_this.removeAttr("disabled");
				$_this.bind("click", function(){
					options["delFunc"]();
				});
			}else{
				$_this.removeClass(btnClass).addClass("btn-muted");
				//$_this.attr("disabled", "disabled");
				$_this.unbind("click");
			}
		},
		btnGray : function(options){
			var $_this = $(this);
			var btnClass = "btn-danger";
			if(options && options["btnClass"]){
				btnClass = options["btnClass"];
			}
			//$_this.attr("disabled", "disabled");
			$_this.removeClass(btnClass).addClass("btn-muted");
			$_this.unbind("click");
		}
	};
	
	$.fn.btnStyleAndEvent = function(method){
		if(btnStyleAndEvent[method]){
			return btnStyleAndEvent[method].apply(this, Array.prototype.slice.call(arguments, 1));
		}else{
			console.log("this event is not supported by the current component(deleteBtnEvent.js)");
		}
	};
}(jQuery));

//查询绑定回车事件
/**
 *
 * @param id	输入框id
 * @param functionName		查询方法名
 * @param type				pageNumber(enter键查询时传type，0表示不分页，1表示分页从1开始，2表示分页从0开始)
 * @param flag				页面高级查询或者是低级查询
 */
function selectBindEnter(id,functionName,type,flag){

    $('#'+id).bind('keypress',function(event){
        if(event.keyCode == '13')
        {
            if(type == 1){
                if(flag!=null){
                    functionName(type,flag);
                }else {
                    functionName(type);
                }
            }else if(type == 0){
                functionName();
            }else if(type == 2){
                functionName(0);
            }
        }
    });
}

/**
 * 防止篡改参数的href跳转
 * @param url
 * @param params
 * @Deprecated 此方法错误的使用防止篡改参数的href跳转，现在使用普通的链接跳转
 */
function forwordHtmlHref(signatureUrl, url, params,_blank){
    var parameters = "";
    for (var name in params) {
        if(name.indexOf("path_variable_") >= 0){
            continue;
        }
        if(parameters == ""){
            parameters += name + "=" + params[name];
        } else{
            parameters += "&" + name + "=" + params[name];
        }
    }
    if(_blank && "_blank" == _blank){
        if(parameters) {
            window.open(url + "?" + parameters,"_blank");
        } else {
            window.open(url,"_blank");
        }
    } else if(_blank == "opener"){
        if(parameters) {
            opener.document.location = url + "?" + parameters;
        } else {
            opener.document.location = url;
        }
        window.close();
    } else {
        if(parameters) {
            window.location.href = url + "?" + parameters;
        } else {
            window.location.href = url;
        }
    }
	/*$.ajax({
		url: signatureUrl,
		data:params,
		type:"post",
		dataType:"json",
		success: function (data) {
			if(data && data.res == 1){
				var parameters = "";
				params.signature = data.signature;
				for (var name in params) {
					if(name.indexOf("path_variable_") >= 0){
						continue;
					}
					if(parameters == ""){
						parameters += name + "=" + params[name];
					} else{
						parameters += "&" + name + "=" + params[name];
					}
				}
				if(_blank && "_blank" == _blank){
					window.open(url + "?" + parameters,"_blank");
				} else if(_blank == "opener"){
					opener.document.location = url + "?" + parameters;
					window.close();
				} else {
					window.location.href = url + "?" + parameters;
				}
			}
		}
	});*/
}

function checkSpecialCharacter(val){
    var re=/[，\s_'’‘\"”“|\\~#$@%^&*!。;\/<>\?？]/;
    if(re.test(val)){
        return false;
    }
    return true;
}

function alertWrong(content) {
    return $.alert({
        title: "警告！",
        message: content,
        type: "warning",
        ok: function () {
        }
    });
}

//获取浏览器类型和版本
function getExplore(){
    var Sys = {};
    var ua = navigator.userAgent.toLowerCase();
    var s;
    (s = ua.match(/rv:([\d.]+)\) like gecko/)) ? Sys.ie = s[1] :
        (s = ua.match(/msie ([\d\.]+)/)) ? Sys.ie = s[1] :
            (s = ua.match(/edge\/([\d\.]+)/)) ? Sys.edge = s[1] :
                (s = ua.match(/firefox\/([\d\.]+)/)) ? Sys.firefox = s[1] :
                    (s = ua.match(/(?:opera|opr).([\d\.]+)/)) ? Sys.opera = s[1] :
                        (s = ua.match(/chrome\/([\d\.]+)/)) ? Sys.chrome = s[1] :
                            (s = ua.match(/version\/([\d\.]+).*safari/)) ? Sys.safari = s[1] : 0;
    // 根据关系进行判断
    if (Sys.ie) return ('IE: ' + Sys.ie);
    if (Sys.edge) return ('EDGE: ' + Sys.edge);
    if (Sys.firefox) return ('Firefox: ' + Sys.firefox);
    if (Sys.chrome) return ('Chrome: ' + Sys.chrome);
    if (Sys.opera) return ('Opera: ' + Sys.opera);
    if (Sys.safari) return ('Safari: ' + Sys.safari);
    return 'Unkonwn';
}

//获取浏览器类型
function getExploreName(){
    var userAgent = navigator.userAgent;
    if(userAgent.indexOf("Opera") > -1 || userAgent.indexOf("OPR") > -1){
        return 'Opera';
    }else if(userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1){
        return 'IE';
    }else if(userAgent.indexOf("Edge") > -1){
        return 'Edge';
    }else if(userAgent.indexOf("Firefox") > -1){
        return 'Firefox';
    }else if(userAgent.indexOf("Safari") > -1 && userAgent.indexOf("Chrome") == -1){
        return 'Safari';
    }else if(userAgent.indexOf("Chrome") > -1 && userAgent.indexOf("Safari") > -1){
        return 'Chrome';
    }else if(!!window.ActiveXObject || "ActiveXObject" in window){
        return 'IE>=11';
    }else{
        return 'Unkonwn';
    }
}

//加法
Number.prototype.add = function(arg){
    var r1,r2,m;
    try{r1=this.toString().split(".")[1].length}catch(e){r1=0}
    try{r2=arg.toString().split(".")[1].length}catch(e){r2=0}
    m=Math.pow(10,Math.max(r1,r2))
    return (this.mul(m) + arg.mul(m)) / m;
};

//减法
Number.prototype.sub = function (arg){
    return this.add(-arg);
};

//乘法
Number.prototype.mul = function (arg)
{
    var m=0,s1=this.toString(),s2=arg.toString();
    try{m+=s1.split(".")[1].length}catch(e){}
    try{m+=s2.split(".")[1].length}catch(e){}
    return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m)
};

//除法
Number.prototype.div = function (arg){
    var t1=0,t2=0,r1,r2;
    try{t1=this.toString().split(".")[1].length}catch(e){}
    try{t2=arg.toString().split(".")[1].length}catch(e){}
    with(Math){
        r1=Number(this.toString().replace(".",""))
        r2=Number(arg.toString().replace(".",""))
        return (r1/r2)*pow(10,t2-t1);
    }
};

(function($) {

// jQuery on an empty object, we are going to use this as our Queue
    var ajaxQueue = $({});

    $.ajaxQueue = function( ajaxOpts ) {
        var jqXHR,
		dfd = $.Deferred(),
		promise = dfd.promise();
        // 将ajax加入运行队列
        ajaxQueue.queue( doRequest );
        // add the abort method
        promise.abort = function( statusText ) {
            // proxy abort to the jqXHR if it is active
            if ( jqXHR ) {
                return jqXHR.abort( statusText );
            }
            // if there wasn't already a jqXHR we need to remove from queue
            var queue = ajaxQueue.queue(),
                index = $.inArray( doRequest, queue );

            if ( index > -1 ) {
                queue.splice( index, 1 );
            }

            // and then reject the deferred
            dfd.rejectWith( ajaxOpts.context || ajaxOpts, [ promise, statusText, "" ] );
            return promise;
        };
        // run the actual query
        function doRequest( next ) {
            jqXHR = $.ajax( ajaxOpts )
                .done( dfd.resolve )
                .fail( dfd.reject )
                .then( next, next );
        }

        return promise;
    };
})(jQuery);

/**
 * 获取浏览器，版本
 * 
 * @returns {getBroswer.publicJSAnonym$6|getBroswer.publicJSAnonym$5|getBroswer.publicJSAnonym$4|getBroswer.publicJSAnonym$1|getBroswer.publicJSAnonym$3|getBroswer.publicJSAnonym$2|getBroswer.publicJSAnonym$7}
 */
function getBroswer(){
    var Sys = {};
    var ua = navigator.userAgent.toLowerCase();
    var s;
    (s = ua.match(/edge\/([\d.]+)/)) ? Sys.edge = s[1] :
        (s = ua.match(/rv:([\d.]+)\) like gecko/)) ? Sys.ie = s[1] :
            (s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] :
                (s = ua.match(/firefox\/([\d.]+)/)) ? Sys.firefox = s[1] :
                    (s = ua.match(/chrome\/([\d.]+)/)) ? Sys.chrome = s[1] :
                        (s = ua.match(/opera.([\d.]+)/)) ? Sys.opera = s[1] :
                            (s = ua.match(/version\/([\d.]+).*safari/)) ? Sys.safari = s[1] : 0;
    if (Sys.edge) return { broswer : "Edge", version : Sys.edge };
    if (Sys.ie) return { broswer : "IE", version : Sys.ie };
    if (Sys.firefox) return { broswer : "Firefox", version : Sys.firefox };
    if (Sys.chrome) return { broswer : "Chrome", version : Sys.chrome };
    if (Sys.opera) return { broswer : "Opera", version : Sys.opera };
    if (Sys.safari) return { broswer : "Safari", version : Sys.safari };

    return { broswer : "", version : "0" };
}
