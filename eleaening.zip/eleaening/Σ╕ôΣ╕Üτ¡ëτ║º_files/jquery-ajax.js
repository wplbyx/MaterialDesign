
var cn = {};
cn.howso = {};
cn.howso.ajaxUtil = {};
cn.howso.ajaxUtil.syncAjax = function(url, params)
{
	var result = null;
	$.ajax({
		type : 'post',
		async : false,
		url : url,
		data: params,
		success : function(data) {
			
			if (data == null) {
				return;
			}
			if (data == "error") {
				return;
			}
			if (data == "success")
			{
				result = {};
				return;
			}
			result = eval("(" + data + ")");
			
		},
		cache : false,
		error : function(xhr, errorText) {
			//errorRedirect(xhr,errorText);
		}
	});
	return result;
}