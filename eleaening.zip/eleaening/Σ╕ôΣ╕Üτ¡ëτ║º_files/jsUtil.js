var iconResolve= {
    colorArr : [ "#ff943e", "#f6bf26", "#f65e5e", "#f65e8d", "#9a89b9", "#5c6bc0", "#78919d","#6bb5ce", "#74bef2", "#38adff" ],
    getColorByNumber:function (number) {
        number+="";
        if (number != null && number.length > 0) {
            try {
                var num = number.substring(number.length - 1, number.length);
                return this.colorArr[num];
            } catch (e) {
                return this.colorArr[0];
            }
        } else {
            return this.colorArr[0];
        }
    },
    getSimpleBName:function (name) {
        // 截取的分段
        var partArr = null;
        var oneSpaceName = name.replaceAll(" +", " ").trim();
        // 正则表达式检测是否是纯英文
        var pattern = new RegExp("^[a-zA-Z\\s+]*");
        var isEnName = oneSpaceName.match(pattern);
        if (""!=isEnName) // 执行纯英文字母判断
        {
            partArr = oneSpaceName.split(" ");
            if (partArr.length >= 2) {
                return partArr[0].substring(0, 1) + partArr[1].substring(0, 1);
            } else if (partArr.length == 1) {
                if (name.length >= 2) {
                    var len = partArr[0].length;
                    return partArr[0].substring(0, 2);
                } else {
                    return partArr[0];
                }
            } else {
                return "";
            }
        } else// 不是则截取后面两位字符
        {
            if (oneSpaceName.length >= 2) {
                var len = oneSpaceName.length;
                return oneSpaceName.substring(len - 2, len);
            } else {
                return oneSpaceName;
            }
        }
    }
}

var headIcon = {
    createHeaderIconForDiscussion: function (path, name, id) {
        if (path === null || path === undefined || path === '' || path.indexOf("default_") >= 0
                || path.indexOf("anything_") >= 0) {
            return "<a class='blog-pimg m-r-md' href='javascript:void(0);' style = 'width: 40px; height: 40px;line-height:40px;cursor:default;background-color:"
                    + iconResolve.getColorByNumber(id) + "'>" + iconResolve.getSimpleBName(name) + "</a>"
        } else {
            return "<a class='m-r-md' href='javascript:void(0);' style='cursor:default;'>" +
                    "<img class='img-circle' src='" + path + "'></a>";
        }
    },
    createHeaderIconForList:function (path,name,id) {
        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
                return "<a class='blog-pimg' href='javascript:void(0);' style = 'width: 40px; height: 40px;line-height:40px;cursor:default;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
                return "<a href='javascript:void(0);' style='cursor:default;'><img style='width: 40px; height: 40px;border-radius: 50% !important;' data-pinit='registered' src='"+path+"'></a>";
        }
    },
    createSmallHeaderIconForList:function (path,name,id) {
        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
                return "<a class='blog-pimg' href='javascript:void(0);' style = 'cursor:default;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
                return "<a href='javascript:void(0);' style='cursor:default;'><img style='width: 34px; height: 34px;border-radius: 50% !important;' data-pinit='registered' src='"+path+"'></a>";
        }
    },
    createMoreSmallHeaderIconForList:function (path,name,id) {
        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
                return "<a class='blog-pimg' href='javascript:void(0);' style = 'height:32px;width:32px;line-height:32px; cursor:default;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
                return "<a href='javascript:void(0);' style='cursor:default;'><img class='img-circle img-sm' data-pinit='registered' src='"+path+"'></a>";
        }
    },
    createHeaderIconForCommunity:function (path,name,id) {
        if(path==""||path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            return "<a class='blog-pimg' href='javascript:void(0);' style = 'cursor:default;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
            return "<a href='javascript:void(0);' style='cursor:default;'><img style='width: 40px;'  src='"+path+"'></a>";
        }
    },
    createHeaderIconForAssessMent:function (path,name,id) {
        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            return "<a href='javascript:void(0);'  style = 'background-color:#000;"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
            return "<a href='javascript:void(0);' style='cursor:default;'><img  src='"+path+"' class='img-circle' ></a>";
        }
    },
    createMineHeaderIconForCommunity:function (path,name,id) {
        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            return "<a class='blog-pimg'  style = 'cursor:default;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
            return "<a style='cursor:default;'><img  src='"+path+"'></a>";
        }
    },
    createTitleIcon:function (dom,name,id) {
        var path = $(dom).attr("src");
        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {

            var htm = $("<a class='blog-pimg' href='javascript:void(0)' class='no-padding' style ='height:48px;width: 48px;line-height: 48px; font-size:14px; background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>");
            $(dom).after(htm);
            $(dom).remove();
        }
        else
        {
            var htm = $("<a href='javascript:void(0)' class='no-padding'><img style='width: 48px;height: 48px;' class='img-circle' src='"+path+"'></a>");
            $(dom).after(htm);
            $(dom).remove();

        }
    },
    createSmallTitleIcon:function (dom,name,id) {
        var path = $(dom).attr("src");
        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            var htm = $("<a class='blog-pimg' href='javascript:void(0)' class='no-padding' style ='height:32px;width:32px;line-height:32px; font-size:12px; background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>");
            $(dom).after(htm);
            $(dom).remove();
        }
        else
        {
            var htm = $("<a href='javascript:void(0)' class='no-padding'><img style='width:32px;height:32px;' class='img-circle' src='"+path+"'></a>");
            $(dom).after(htm);
            $(dom).remove();

        }
    },
    createInfoIcon:function (dom,path,name,id) {

        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            var htm = $("<a id='"+$(dom).attr("id")+"' class='blog-pimg' href='javascript:void(0);' style = 'cursor:default;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>");
            $(dom).after(htm);
            $(dom).remove();
        }
        else
        {
            var htm = $("<a id='"+$(dom).attr("id")+"' href='javascript:void(0);' style='cursor:default;'><img style='border-radius: 50% !important;' src='"+path+"'></a>");
            $(dom).after(htm);
            $(dom).remove();
        }
    },
    getUserHeaderIcon:function (path,name,id) {
        if(path==null||path=='null'||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            return "<a class='blog-pimg' href='javascript:void(0);' style = 'width:68px;height:68px;cursor:default;font-size: 18px !important;line-height: 68px;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
            return "<img style='width: 68px; height: 68px;border-radius: 50% !important;' data-pinit='registered' src='"+path+"'>";
        }
    },
    getCommunityUserHeaderIcon:function (path,name,id) {
        if(path==''||path==null||path=='null'||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            return "<a class='blog-pimg pull-left' href='javascript:void(0);' style = 'cursor:default;font-size: 12px !important;line-height: 39px;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
            return "<img class='img-circle'  src='"+path+"'>";
        }
    },
    gethsstatisticsUserHeaderIcon:function (path,name,id) {
        if(path==''||path==null||path=='null'||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            return "<a class='blog-pimg' href='javascript:void(0);' style = 'cursor:default;font-size: 12px !important;line-height: 39px;background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>"
        }
        else
        {
            return "<img class='img-circle'  src='"+path+"'>";
        }
    },
    createBigTitleIcon:function (dom,name,id) {
        var path = $(dom).attr("src");
        if(path==null||path==undefined||path.indexOf("default_")>=0||path.indexOf("anything_")>=0)
        {
            var htm = $("<a class='blog-pimg' href='javascript:void(0)' class='no-padding' style ='height:96px;width:96px;line-height:96px; font-size:16px; background-color:"+iconResolve.getColorByNumber(id)+"'>"+iconResolve.getSimpleBName(name)+"</a>");
            $(dom).after(htm);
            $(dom).remove();
        }
        else
        {
            var htm = $("<a href='javascript:void(0)' class='no-padding'><img style='width:96px;height:96px;' class='img-circle' src='"+path+"'></a>");
            $(dom).after(htm);
            $(dom).remove();

        }
    },
}
