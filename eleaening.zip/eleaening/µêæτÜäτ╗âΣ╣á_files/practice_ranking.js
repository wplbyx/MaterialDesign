// http://www.chartjs.org/docs/latest/general/options.html
// http://www.itkeyword.com/doc/411872169390584x990/chartjs-how-to-set-max-and-min-value-for-y-axis
var lineOptions = {
    responsive: true,
    scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
    }
};
var lineOptionYear = {
    labels: [],
    datasets: [
        {
            label: "总题数",
            backgroundColor: "rgba(26,179,148,0.5)",
            borderColor: "rgba(26,179,148,0.3)",
            pointBackgroundColor: "rgba(26,179,148,0.1)",
            pointBorderColor: "",
            data: []
        },
        {
            label: "答对题数",
            backgroundColor: "rgba(36,137,199,0.5)",
            borderColor: "rgba(36,137,199,0.3)",
            pointBackgroundColor: "rgba(36,137,199,0.1)",
            pointBorderColor: "",
            data: []
        }
    ]
};

var lineOptionMonth = {
    labels: [],
    datasets: [
        {
            label: "总题数",
            backgroundColor: "rgba(26,179,148,0.5)",
            borderColor: "rgba(26,179,148,0.3)",
            pointBackgroundColor: "rgba(26,179,148,0.1)",
            pointBorderColor: "",
            data: []
        },
        {
            label: "答对题数",
            backgroundColor: "rgba(36,137,199,0.5)",
            borderColor: "rgba(36,137,199,0.3)",
            pointBackgroundColor: "rgba(36,137,199,0.1)",
            pointBorderColor: "",
            data: []
        }
    ]
};

function initPracticeTotal(){

    $.ajax({
        type : "post",
        url : AJAX_URLS.obtainThisMonthPracticeData,
        data: {
            userId : parameter.userId
        },
        dataType: "json",
        success : function(data) {
            if(data == null){
                return;
            }
            var rightPercent = 0;
            if(data.count > 0){
                rightPercent = (Number(data.right) * 100 / Number(data.count)).toFixed(0);
            }
            $("#yearAndmonthRankPercent").html(rightPercent);
            $("#yearAndmonthRankPercentDot").attr("style","left:" + rightPercent + "%")
            lineOptionMonth.labels = data.days;
            lineOptionMonth.datasets[0].data = data.totals;
            lineOptionMonth.datasets[1].data = data.rights;
            var max1 = Math.max.apply(null, data.totals);
            if (max1 <= 10) {
                lineOptions = {
                    responsive: true,
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                steps: 1,
                                stepValue: 1,
                                max: 10
                            },
                        }]
                    }
                };
            } else {
                lineOptions = {
                    responsive: true,
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                steps: 10,
                                stepValue: 5,
                            },
                        }]
                    }
                };
            }
            var ctx = document.getElementById("lineChart1").getContext("2d");
            new Chart(ctx, {type: 'line', data: lineOptionMonth, options: lineOptions});
        }
    });

    $.ajax({
        type : "post",
        url : AJAX_URLS.obtainThisYearPracticeData,
        data: {
            userId : parameter.userId
        },
        dataType: "json",
        success : function(data) {
            if(data == null){
                return;
            }
            var rightPercent = 0;
            if(data.count > 0){
                rightPercent = (Number(data.right) * 100 / Number(data.count)).toFixed(0);
            }
            $("#yearRankPercent").html(rightPercent);
            $("#yearRankPercentDot").attr("style","left:" + rightPercent + "%")
            lineOptionYear.labels = data.months;
            lineOptionYear.datasets[0].data = data.totals;
            lineOptionYear.datasets[1].data = data.rights;
            var max1 = Math.max.apply(null, data.totals);
            if (max1 <= 10) {
                lineOptions = {
                    responsive: true,
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                steps: 1,
                                stepValue: 1,
                                max: 10
                            },
                        }]
                    }
                };
            } else {
                lineOptions = {
                    responsive: true,
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                steps: 10,
                                stepValue: 5,
                            },
                        }]
                    }
                };
            }

            var ctx = document.getElementById("lineChart").getContext("2d");
            new Chart(ctx, {type: 'line', data: lineOptionYear, options: lineOptions});
        }
    });
}

function initPracticeRank(page) {
    var pageSize = $.cookie("practiceRankHistoryPractice");
    if (pageSize == null || pageSize == "") {
        pageSize = 10;
    }
    var $_content = $("#practiceRankList");
    $_content.empty();
    $("#practiceRankListPagepage").empty();
    parameter.practiceRank.getLoadingLabel();
    $.ajax({
        type: "post",
        url: AJAX_URLS.getOrgThisMonthRankingList,
        data: {
            pageNumber : page,
            pageSize : pageSize,
            sortType : "rate"
        },
        dataType: "json",
        success : function(data) {
            data = data.data.page;
            if (data == null) {
                parameter.practiceRank.getFaildLabel("出错啦");
                return;
            } else if (data.totalCount == null || data.totalCount == '' || data.totalCount == 'null' || data.totalCount == 0) {
                parameter.practiceRank.getNoneDataLabel("");
                return;
            } else {
                parameter.practiceRank.emptyParentDom();
            }
            new PaginationPage("practiceRankListPage", initPracticeRank, data,true);
            var html = "";
            var userIds = [];
            $.each(data.items, function (i, row) {
                html += '<tr>';
                if(page == 0 && i == 0){
                    html += '<td><i class="ranking-list rank1"></i></td>';
                }else if(page == 0 && i == 1){
                    html += '<td><i class="ranking-list rank2"></i></td>';
                }else if(page == 0 && i == 2){
                    html += '<td><i class="ranking-list rank3"></i></td>';
                }else{
                    html += '<td>'+(page* pageSize+i+1)+'</td>';
                }
                html += '<td>';
                if (row.picPath != null && row.picPath != undefined && row.picPath != 'null' && row.picPath != '' && row.picPath != 'undefined' && row.picPath.indexOf("default_") < 0) {
                    html += '<img alt="image" class="img-circle m-r-xs" style="height:48px;width: 48px;" src="' + BOS_IMG_PATH + row.picPath + '">';
                } else {
                    html += "<a class='blog-pimg m-r-xs' href='javascript:void(0)' style ='height:48px;width: 48px;line-height: 48px; font-size:14px; background-color:" + iconResolve.getColorByNumber(row.userId) + "'>" + iconResolve.getSimpleBName(row.userName) + "</a>";
                }
                html += row.userName;
                html += '</td>';
                userIds.push(row.userId);
                html += '<td id="depMonth' + row.userId + '"></td>';
                html += '<td>' + row.rightNum + '</td>';
                html += '<td>' + row.totalNum + '</td>';
                var percent = (row.rightNum * 100) / row.totalNum;
                html += '<td>' + percent.toFixed(0) + '%</td>';
                html += '<td><a href="javascript:void(0)" onclick="viewDetail(' + row.userId + ',1)">查看详情</a></td>';
            });
            $_content.html(html);
            pageNumber2 = data.pageNumber;
            getDepIdByUserIds(userIds.join(","), 'depMonth');
        }
    });
}

function initPracticeYearRank(page) {
    var pageSize = $.cookie("practiceYearRankHistoryPractice");
    if (pageSize == null || pageSize == "") {
        pageSize = 10;
    }
    var $_content = $("#practiceYearRankList");
    $_content.empty();
    $("#practiceYearRankListPagepage").empty();
    parameter.myPracticeYearRank.getLoadingLabel();
    $.ajax({
        type: "post",
        url: AJAX_URLS.getOrgThisYearRankingList,
        data: {
            pageNum: page,
            pageSize: pageSize,
            sortType: "rate"
        },
        dataType: "json",
        success : function(data) {
            data = data.data.page;
            if (data == null) {
                parameter.myPracticeYearRank.getFaildLabel("出错啦");
                return;
            } else if (data.totalCount == null || data.totalCount == '' || data.totalCount == 'null' || data.totalCount == 0) {
                parameter.myPracticeYearRank.getNoneDataLabel("");
                return;
            } else {
                parameter.myPracticeYearRank.emptyParentDom();
            }
            new PaginationPage("practiceYearRankListPage", initPracticeYearRank, data,true);
            var html = "";
            var userIds = [];
            $.each(data.items, function (i, row) {
                html += '<tr>';
                if(page == 0 && i == 0){
                    html += '<td><i class="ranking-list rank1"></i></td>';
                }else if(page == 0 && i == 1){
                    html += '<td><i class="ranking-list rank2"></i></td>';
                }else if(page == 0 && i == 2){
                    html += '<td><i class="ranking-list rank3"></i></td>';
                }else{
                    // html += '<td>'+((page-1) * pageSize+i+1)+'</td>';
                    html += '<td>'+(page* pageSize+i+1)+'</td>';
                }
                html += '<td>';
                if (row.picPath != null && row.picPath != undefined && row.picPath != 'null' && row.picPath != '' && row.picPath != 'undefined' && row.picPath.indexOf("default_") < 0) {
                    html += '<img alt="image" class="img-circle" style="height: 48px;width: 48px;" src="' + BOS_IMG_PATH + row.picPath + '">';
                } else {
                    html += "<a class='blog-pimg' href='javascript:void(0)' class='no-padding' style ='height:48px;width: 48px;line-height: 48px; font-size:14px; background-color:" + iconResolve.getColorByNumber(row.userId) + "'>" + iconResolve.getSimpleBName(row.userName) + "</a>";
                }
                html += row.userName;
                html += '</td>';
                userIds.push(row.userId);
                html += '<td id="depYear' + row.userId + '"></td>';
                html += '<td>' + row.rightNum + '</td>';
                html += '<td>' + row.totalNum + '</td>';
                var percent = (row.rightNum * 100) / row.totalNum;
                html += '<td>' + percent.toFixed(0) + '%</td>';
                html += '<td><a href="javascript:void(0)" onclick="viewDetail(' + row.userId + ',2)">查看详情</a></td>';
            });
            $_content.html(html);
            pageNumber3 = data.pageNumber;
            getDepIdByUserIds(userIds.join(","), 'depYear');
        }
    });
}

function findDepNameByUserId(userId) {
    var depName = "";
    $.ajax({
        type: "post",
        url: AJAX_URLS.findDepNameByUserId,
        data: {
            userId: userId
        },
        async: false,
        success: function (data) {
            depName = data;
        }
    });
    return depName;
}

function getDepIdByUserIds(userIds, obj) {
    $.ajax({
        type: "post",
        url: AJAX_URLS.getDepIdByUserIds,
        data: {
            userIds: userIds
        },
        async: false,
        success: function (data) {
            if (data != null && data != undefined && data != '' && data != 'null' && data != 'undefined') {
                var userArr = userIds.split(",");
                var DATAJOSN = eval("(" + data + ")");
                for (var i = 0; i < userArr.length; i++) {
                    if (DATAJOSN[userArr[i]] != null && DATAJOSN[userArr[i]] != undefined && DATAJOSN[userArr[i]] != '' && DATAJOSN[userArr[i]] != 'null' && DATAJOSN[userArr[i]] != 'undefined') {
                        $("#" + obj + userArr[i]).html(DepInfo_function.getOnlyDepNameById(DATAJOSN[userArr[i]]));
                    } else {
                        $("#" + obj + userArr[i]).html("");
                    }
                }
            }
        }
    });
}

function changeRank(obj, type) {
    if (type == 1) {
        if (!$("#span_month").hasClass("text-navy")) {
            $("#span_month").addClass("text-navy");
        }
        if ($("#span_year").hasClass("text-navy")) {
            $("#span_year").removeClass("text-navy");
        }
        $("#monthRankDiv").show();
        $("#yearRankDiv").hide();
    } else {
        if ($("#span_month").hasClass("text-navy")) {
            $("#span_month").removeClass("text-navy");
        }
        if (!$("#span_year").hasClass("text-navy")) {
            $("#span_year").addClass("text-navy");
        }
        $("#yearRankDiv").show();
        $("#monthRankDiv").hide();
    }
}


//////////加载头部饼图   start 2017年9月13日16:36:10//////////////
function initPracticePieChart() {
    $.ajax({
        type: "post",
        url: AJAX_URLS.getUserMonthRankingInfo,
        data: {
            userId: parameter.userId
        },
        dataType: "json",
        success: function (data) {
            if (null == data) {
                return;
            }
            if (data.ranking4TotalNum < 0) {
                $("#thisMonthRank").html("--");
            } else {
                $("#thisMonthRank").html(data.ranking4TotalNum);
            }
            if (data.ranking4TotalNum < 0) {
                $("#answerTotalRank").html("--");
            } else {
                $("#answerTotalRank").html(data.ranking4TotalNum);
            }
            $("#answerTotal").html(data.totalCount);
            if (data.ranking4RightRate < 0) {
                $("#answerRightRank").html("--");
            } else {
                $("#answerRightRank").html(data.ranking4RightRate);
            }
            $("#answerRight").html(data.rightCount);

            var wrong = data.totalCount - data.rightCount;
            var right = data.rightCount;

            if (right > 0 || wrong > 0) {
                $("#morris1").show();
                $("#morris2").hide();
                Morris.Donut({
                    element: 'morris-donut-chart',
                    data: [{label: "答对题数", value: right}, {label: "答错题数", value: wrong}],
                    resize: false,
                    colors: ['#34d7c4', '#ffc65d'],
                    labelColor: '#666',
                });
                var $svg = $("#morris-donut-chart").find('svg');
                $svg.css({
                    'margin-top': '-65px',
                    'height': '253px'
                });
            } else {
                $("#morris2").show();
                $("#morris1").hide();
            }


        }
    });
}

//////////加载头部饼图   end  2017年9月13日16:36:06//////////////


/////////////////////////加载头部左侧信息   start   2017年9月13日17:56:04/////
function initPeopleIntroduction() {
    $.ajax({
        type: "post",
        url: AJAX_URLS.searchUserByUuidAndId,
        data: {
            userId: parameter.userId,
        },
        dataType: "json",
        success: function (data) {
            if (null == data) {
                return;
            }
            $("#peopleInfo").html("");
            var html = "";
            if (data.picPath != "" && data.picPath != null && data.picPath != undefined && data.picPath != 'null' && data.picPath != '' && data.picPath != 'undefined' && data.picPath.indexOf("default_") < 0) {
                html += '<img alt="image" style="width: 200px;height: 200px;" class="img-circle m-t-lg" src="' + BOS_IMG_PATH + data.picPath + '!200_200.png">';
            } else {
                html += "<a class='blog-pimg m-t-lg' href='javascript:void(0)' style ='height:96px;width: 96px;line-height: 96px; font-size:20px; background-color:" + iconResolve.getColorByNumber(data.id) + "'>" + iconResolve.getSimpleBName(data.username) + "</a>";
            }
            html += '<p class="f30 text-navy">' + data.username + '<i class="m-l-sm info-sex female"></i></p>';
            var depName = findDepNameByUserId(data.id);
            html += '<p class="f14 text-gray"><span>' + depName + '</span></p>';
            $("#peopleInfo").html(html);
        }
    });
}

/////////////////////////加载头部左侧信息   end   2017年9月13日17:56:04/////


function viewDetail(userId, type) {
    window.location.href = AJAX_URLS.practiceTotalInfo + "?userId=" + userId + "&type=" + type;
}


