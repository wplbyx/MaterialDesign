var noneDataDom = new Label({'parentDom':$("#noneDataDom")});

$(function () {
	//查询绑定回车事件
	selectBindEnter("keyword",getExamInfo,2);

	// getExamInfo(0);
	// selectBindEnter("keyword",getExamInfo,1);
    if(examStatus=="true"){
        $("[data-status='1']").removeClass("btn btn-primary");
        $("[data-status='1']").addClass("btn btn-white");
        $("[data-status='2']").removeClass("btn btn-white");
        $("[data-status='2']").addClass("btn btn-primary");
	}
    getExamInfo(0);

	//选择试卷状态
	$("#examStatus").on("click","button",function(){
		$(this).siblings(".btn-primary").addClass("btn-white");
		$(this).siblings(".btn-primary").removeClass("btn-primary");
		$(this).removeClass("btn-white");
		$(this).addClass("btn-primary");
		getExamInfo(0);
	});
});

function getExamInfo(pageNum){
	var pageSize=$.cookie("myExamList");
	if(pageSize==null||pageSize==""){
		pageSize=10;
	}
	var keyword=$("#keyword").val();
	if(keyword!=null&&keyword!=""){
		if (keyword.indexOf("%") > -1) {
			keyword = keyword.replace("%", "\\%");
    	}
		keyword = keyword.replace("'", "\\'");
	}
	var examStatus = $("#examStatus").find(".btn-primary").attr("data-status");
	$("#myexam-list").empty();
	$("#myExamListpage").empty();
	noneDataDom.getLoadingLabel();
	$.ajax({
		url : urls.queryMyExamList,
		type : "post",
		data : {
			"keyword" : keyword,
			"examStatus" : examStatus,
			"pageNumber":pageNum,
			"pageSize":pageSize
		},
		dataType : "json",
		success : function(data) {
			if (data == null) {return;}
			var datalist = data.data.pagination;
			if(datalist==null)return;
			new PaginationPage("myExamList", getExamInfo, datalist,true);
			if(datalist && datalist.items && datalist.items.length>0){
				noneDataDom.emptyParentDom();
				getContentHTML(datalist.items, data.data.nowDate);
			}else{
				noneDataDom.getNoneDataLabel("暂无考试~",'exam');
			}
		},
		cache : false,
		error : function(xhr, errorText) {
		}
	});
}
function getContentHTML(examList, nowDate){
	var $_myexamList = $("#myexam-list");
	for(var i = 0;i < examList.length;i++){
		var itemHtml = "";
		var differentShowObj  = examDifferentStatusShow(examList[i], nowDate);
		
		var examineeStartTime = examList[i].startTime.replace(".0","").replaceAll("-","/");// 考生入场考试时间
		var examineeEndTime = examList[i].endTime.replace(".0","").replaceAll("-","/");// 考生结束考试时间
		var examStartTime = examList[i].examStartTime.replace(".0","");      		
		var examEndTime = examList[i].examEndTime.replace(".0","");
		var examStartDate = new Date(examStartTime.replaceAll("-","/"));
		var examEndDate = new Date(examEndTime.replaceAll("-","/"));
		
		/*var divDom = '<div class="p-md bg-muted border-top-bottom border-left-right m-b-md">';*/
		/*if(examEndDate < nowDate){
			//考试时间已结束
			if(examineeStartTime==""){
			}else{
				//判断是否保密考试
				if(examList[i].isCheck == 100){
				}else{
					//该考试不可以查阅
					if(examList[i].isCheck == 200){
					}else{
						divDom = '<div class="p-md bg-muted border-top-bottom border-left-right m-b-md" style="cursor: pointer" onclick="toExamHistory('+examList[i].id+')">';
						//differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="toExamHistory('+examList[i].id+')">查看考试</button>';	
					}
				}
			}
		}else{
			//考试时间未结束
			if(examStartDate < nowDate){
				if(examineeStartTime != ""){
					if(examineeEndTime != ""){
						if(examList[i].isCheck == 100){
						}else{
							//该考试不可以查阅
							if(examList[i].isCheck == 200){
							}else{
								divDom = '<div class="p-md bg-muted border-top-bottom border-left-right m-b-md" style="cursor: pointer" onclick="toExamHistory('+examList[i].id+')">';
								//differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="toExamHistory('+examList[i].id+')">查看考试</button>';	
							}
						}
					}else{
						//已入场
						var closeStamp=new Date(examineeStartTime).getTime() + examList[i].duration*60*1000;
						var submitStamp = examEndDate.getTime();
						if(closeStamp < examEndDate.getTime()){
							submitStamp = closeStamp;
						}
						if(submitStamp && submitStamp > 0 && submitStamp > new Date(nowDate).getTime()){
							divDom = '<div class="p-md bg-muted border-top-bottom border-left-right m-b-md" style="cursor: pointer" onclick="toExamInfo('+examList[i].id+')">';
							//differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="toExamInfo('+examList[i].id+')">继续考试</button>'+
								//'<p class="text-warning f12 no-margins"><i class="fa fa-clock-o"></i> 剩余' + getExamTimes(Math.round((submitStamp - new Date(nowDate).getTime())/1000)) + '</p>';
						}else{
							//判断是否保密考试
							if(examList[i].isCheck == 100){
							}else{
								//该考试不可以查阅
								if(examList[i].isCheck == 200){
								}else{
									divDom = '<div class="p-md bg-muted border-top-bottom border-left-right m-b-md" style="cursor: pointer" onclick="toExamHistory('+examList[i].id+')">';
									//differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="toExamHistory('+examList[i].id+')">查看考试</button>';	
								}
							}
						}
					}
				}else{
					divDom = '<div class="p-md bg-muted border-top-bottom border-left-right m-b-md" style="cursor: pointer" onclick="beginExam('+examList[i].id+')">';
					//未入场
					//differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="beginExam('+examList[i].id+')">开始考试</button>';
				}
			}else{
			}
		}*/
		
		//itemHtml += '<div class="p-md bg-muted border-top-bottom border-left-right m-b-md">';
		/*itemHtml += divDom;
			itemHtml += '<div class="row">';
				itemHtml += '<div class="col-lg-2">';
					itemHtml += '<section class="table-cell text-left">';
						itemHtml +=differentShowObj["labelHtml"];
	                itemHtml += '</section>';
				itemHtml += '</div>';
				itemHtml += '<div class="col-lg-5">';
					//设置label
					itemHtml += '<h2 class="m-b-xs f18">' + examList[i].examName + '</h2>';
					itemHtml += '<p class="m-t-sm">';
						itemHtml += '<span class="m-r-lg">考试时长：<font>'+examList[i].duration+'</font>分钟</span>';
						itemHtml += '<span class="">总分：<font>'+examList[i].totalScores+'</font>分</span>';
                    itemHtml += '</p>';
                    itemHtml += '<p class="m-t-sm">';
                    	itemHtml += differentShowObj["submitType"];
                    	itemHtml += '<span class="m-r-sm">开场时间：<font>'+new Date(examStartDate).Format("MM 月 dd 日  hh:mm")+'</font></span>';
                        itemHtml += '<span class="">闭场时间：<font>'+new Date(examEndDate).Format("MM 月 dd 日  hh:mm")+'</font></span>';       
                    itemHtml += '</p>';
				itemHtml += '</div>';
				itemHtml += '<div class="col-lg-2">';
					itemHtml += '<section class="table-cell">';
						itemHtml += differentShowObj["showSocre"];
					itemHtml += '</section>';
				itemHtml += '</div>';
				itemHtml += '<div class="col-lg-3">';
					itemHtml += '<section class="table-cell">';
						//控制当前显示
						itemHtml += differentShowObj["showMode"];
					itemHtml += '</section>';
				itemHtml += '</div>';
			itemHtml += '</div>';
		itemHtml += '</div>';*/
		if(differentShowObj["isEvent"] == "toExamHistory"){
			itemHtml = "<tr style='cursor: pointer' onclick='toExamHistory(" + examList[i].id + ")'>"
		}else if(differentShowObj["isEvent"] == "toExamInfo"){
			itemHtml = "<tr style='cursor: pointer' onclick='toExamInfo(" + examList[i].id + ", " + examList[i].isSso + ")'>"
		}else if(differentShowObj["isEvent"] == "beginExam"){
			itemHtml = "<tr style='cursor: pointer' onclick='beginExam(" + examList[i].id + ")'>"
		}else{
			itemHtml = "<tr>"
		}
		if(examList[i].isTraining != null && examList[i].isTraining != undefined && examList[i].isTraining != "" && examList[i].isTraining != 'null' && examList[i].isTraining != "undefined" && (examList[i].isTraining == 1||examList[i].isTraining == 2)){
			itemHtml += "<td>" + differentShowObj["labelHtml"] +readerTrainLabel(examList[i].id, examList[i].isTraining) +"</td>"
		}else{
			itemHtml += "<td>" + differentShowObj["labelHtml"]  +"</td>"
		}

			itemHtml += "<td class=''>"
				itemHtml += "<h2 class='m-b-xs f14 font-bold'>" + examList[i].examName + "</h2>"
				itemHtml += "<p class='m-t-sm f12'>"
					itemHtml += "<span class='m-r-xs'>考试时长：<font>" + examList[i].duration + "</font>分钟</span>"
					itemHtml += "<span class='m-r-xs'>总分：<font>"+ examList[i].totalScores +"</font>分</span>"
					itemHtml += "<span class=''>" + differentShowObj["submitType"] + "</span>"   
				itemHtml += "</p>"
			itemHtml += "</td>"
			itemHtml += "<td>" + differentShowObj["showSocre"] + "</td>"
			itemHtml += "<td class='text-right'>" + differentShowObj["showMode"] + "</td>"
		itemHtml += "</tr>";
		
		$_myexamList.append(itemHtml);
	}
}
function examDifferentStatusShow(exam, nowDate){
	var differentShowObj = {};
	var examineeStartTime = exam.startTime.replace(".0","").replaceAll("-","/");// 考生入场考试时间
	var examineeEndTime = exam.endTime.replace(".0","").replaceAll("-","/");// 考生结束考试时间
	var examStartTime = exam.examStartTime.replace(".0","");      		
	var examEndTime = exam.examEndTime.replace(".0","");
	var examStartDate = new Date(examStartTime.replaceAll("-","/"));
	var examEndDate = new Date(examEndTime.replaceAll("-","/"));
	if(examEndDate < nowDate){
		//考试时间已结束
		if(examineeStartTime==""){
			//未参加
			differentShowObj["labelHtml"] = labels.labelDefault;
			differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="">查看考试</button>';
			differentShowObj["isEvent"] = "toExamHistory";
		}else{
			//判断是否保密考试
			if(exam.isCheck == 100){
				differentShowObj["labelHtml"]  = labels.labelEnd;
				differentShowObj["showMode"] = '<p class="f12 no-margins"><i class="fa fa-lock"></i> 该考试不可查阅</p>';
			}else{
				//已参加
				var isSubCount = exam.isSubCount;// 主观题数量
				var readStatus = exam.readStatus;// 阅卷状态
				if(isSubCount > 0 && readStatus!=1){
					differentShowObj["labelHtml"]  = labels.labelSuccess;
					if(exam.borderlineScore <= exam.grade){
						differentShowObj["showSocre"] = '<span class="f36 text-info">' + exam.grade + '+</span>分';
					}else{
						differentShowObj["showSocre"] = '<span class="f36 text-danger">' + exam.grade + '+</span>分';
					}
				}else{
					differentShowObj["labelHtml"]  = labels.labelEnd;
					if(exam.borderlineScore <= exam.grade){
						differentShowObj["showSocre"] = '<span class="f36 text-info">' + exam.grade + '</span>分';
					}else{
						differentShowObj["showSocre"] = '<span class="f36 text-danger">' + exam.grade + '</span>分';
					}
				}
				//该考试不可以查阅
				if(exam.isCheck == 200){
					
				}else{
//					differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="toExamHistory('+exam.id+')">查看考试</button>';	
					differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="">查看考试</button>';	
					differentShowObj["isEvent"] = "toExamHistory";
				}
			}
			if(exam.submitType == "web_user" ||exam.submitType == "android_user" ||exam.submitType == "iphone_user"){
				differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(examineeEndTime).Format("MM月dd日  hh:mm")+'</font></span>'
					+'<span class="text-navy">主动交卷</span>';
			}else if(exam.submitType){
				differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(examineeEndTime).Format("MM月dd日  hh:mm")+'</font></span>'
					+'<span class="text-navy">自动交卷</span>';
			}else{
				var closeStamp=new Date(examineeStartTime).getTime() + exam.duration*60*1000;
				var submitStamp = examEndDate.getTime();
				if(closeStamp < examEndDate.getTime()){
					submitStamp = closeStamp;
				}
				differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(submitStamp).Format("MM月dd日  hh:mm")+'</font></span>'
					+'<span class="text-navy">自动交卷</span>';
			}
		}
	}else{
		//考试时间未结束
		if(examStartDate < nowDate){
			if(examineeStartTime != ""){
				if(examineeEndTime != ""){
					if(exam.isCheck == 100){
						differentShowObj["labelHtml"]  = labels.labelEnd;
						differentShowObj["showMode"] = '<p class="f12 no-margins"><i class="fa fa-lock"></i> 该考试不可查阅</p>';
					}else{
						var isSubCount = exam.isSubCount;// 主观题数量
						var readStatus = exam.readStatus;// 阅卷状态
						if(isSubCount > 0 && readStatus!=1){
							differentShowObj["labelHtml"]  = labels.labelSuccess;
							if(exam.borderlineScore <= exam.grade){
								differentShowObj["showSocre"] = '<span class="f36 text-info">' + exam.grade + '+</span>分';
							}else{
								differentShowObj["showSocre"] = '<span class="f36 text-danger">' + exam.grade + '+</span>分';
							}
						}else{
							differentShowObj["labelHtml"]  = labels.labelEnd;
							if(exam.borderlineScore <= exam.grade){
								differentShowObj["showSocre"] = '<span class="f36 text-info">' + exam.grade + '</span>分';
							}else{
								differentShowObj["showSocre"] = '<span class="f36 text-danger">' + exam.grade + '</span>分';
							}
						}
						//该考试不可以查阅
						if(exam.isCheck == 200){
							
						}else{
//							differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="toExamHistory('+exam.id+')">查看考试</button>';	
							differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="">查看考试</button>';	
							differentShowObj["isEvent"] = "toExamHistory";
						}
					}
					if(exam.submitType == "web_user" ||exam.submitType == "android_user" ||exam.submitType == "iphone_user"){
						differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(examineeEndTime).Format("MM月dd日  hh:mm")+'</font></span>'
							+'<span class="text-navy">主动交卷</span>';
					}else if(exam.submitType){
						differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(examineeEndTime).Format("MM月dd日  hh:mm")+'</font></span>'
							+'<span class="text-navy">自动交卷</span>';
					}else{
						differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(submitStamp).Format("MM月dd日  hh:mm")+'</font></span>'
							+'<span class="text-navy">自动交卷</span>';
					}
				}else{
					//已入场
					differentShowObj["labelHtml"]  = labels.labelWarning;
					var closeStamp=new Date(examineeStartTime).getTime() + exam.duration*60*1000;
					var submitStamp = examEndDate.getTime();
					if(closeStamp < examEndDate.getTime()){
						submitStamp = closeStamp;
					}
					if(submitStamp && submitStamp > 0 && submitStamp > new Date(nowDate).getTime()){
//						differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="toExamInfo('+exam.id+')">继续考试</button>'+
						differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="">继续考试</button>'+
							'<p class="text-danger f12 no-margins"><i class="fa fa-clock-o"></i> 剩余' + getExamTimes(Math.round((submitStamp - new Date(nowDate).getTime())/1000)) + '</p>';
						differentShowObj["isEvent"] = "toExamInfo";
					}else{
						//判断是否保密考试
						if(exam.isCheck == 100){
							differentShowObj["labelHtml"]  = labels.labelEnd;
							differentShowObj["showMode"] = '<p class="f12 no-margins"><i class="fa fa-lock"></i> 该考试不可查阅</p>';
						}else{
							var isSubCount = exam.isSubCount;// 主观题数量
							var readStatus = exam.readStatus;// 阅卷状态
							if(isSubCount > 0 && readStatus!=1){
								differentShowObj["labelHtml"]  = labels.labelSuccess;
								if(exam.borderlineScore <= exam.grade){
									differentShowObj["showSocre"] = '<span class="f36 text-info">' + exam.grade + '+</span>分';
								}else{
									differentShowObj["showSocre"] = '<span class="f36 text-danger">' + exam.grade + '+</span>分';
								}
							}else{
								differentShowObj["labelHtml"]  = labels.labelEnd;
								if(exam.borderlineScore <= exam.grade){
									differentShowObj["showSocre"] = '<span class="f36 text-info">' + exam.grade + '</span>分';
								}else{
									differentShowObj["showSocre"] = '<span class="f36 text-danger">' + exam.grade + '</span>分';
								}
							}
							//该考试不可以查阅
							if(exam.isCheck == 200){
								
							}else{
//								differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="toExamHistory('+exam.id+')">查看考试</button>';	
								differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="">查看考试</button>';	
								differentShowObj["isEvent"] = "toExamHistory";
							}
						}
						if(exam.submitType == "web_user" ||exam.submitType == "android_user" ||exam.submitType == "iphone_user"){
							differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(examineeEndTime).Format("MM月dd日  hh:mm")+'</font></span>'
								+'<span class="text-navy">主动交卷</span>';
						}else if(exam.submitType){
							differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(examineeEndTime).Format("MM月dd日  hh:mm")+'</font></span>'
								+'<span class="text-navy">自动交卷</span>';
						}else{
							differentShowObj["submitType"] = '<span class="m-r-sm">交卷时间：<font>'+new Date(submitStamp).Format("MM月dd日  hh:mm")+'</font></span>'
								+'<span class="text-navy">自动交卷</span>';
						}
					}
				}
			}else{
				//未入场
				differentShowObj["labelHtml"]  = labels.labelStarted;
//				differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="beginExam('+exam.id+')">开始考试</button>';
				differentShowObj["showMode"] = '<button type="button" class="btn btn-outline btn-primary" onclick="">开始考试</button>';
				differentShowObj["isEvent"] = "beginExam";
			}
		}else{
			//考试时间未到
			differentShowObj["labelHtml"]  = labels.labelPrimary;
			if(exam.stillTimes==0){
				differentShowObj["showMode"] = '<span class="f12">即将开始</span>';
			}else{
				differentShowObj["showMode"] = '<span class="text-success f12 no-margins"><i class="fa fa-clock-o"></i> '+getExamTimes(exam.stillTimes)+'后开始</span>';
			}
		}
	}
	if(!differentShowObj["labelHtml"]){
		differentShowObj["labelHtml"] = "";
	}
	if(!differentShowObj["showMode"]){
		differentShowObj["showMode"] = "";
	}
	if(!differentShowObj["showSocre"]){
		differentShowObj["showSocre"] = "";
	}
	if(!differentShowObj["submitType"]){
		/*differentShowObj["submitType"] = '<span class="m-r-sm">开场时间：<font>'+setNewDateTimeFormat(examStartDate)+'</font></span>'
        	+ '<span class="">闭场时间：<font>'+setNewDateTimeFormat(examEndDate)+'</font></span>';*/
		differentShowObj["submitType"] = '<span class="m-r-sm">起止时间：<font>'+setNewDateTimeFormat(examStartDate)+'</font>~<font>'+setNewDateTimeFormat(examEndDate)+'</font></span>';
	}
	return differentShowObj;
}
function getExamTimes(time){
	var times = time*1;
	var res="";
	if(times<=0){
		times=0;
		return "--";
	}
	if(times==null){
		return "--";
	}
	if(times<60){
		res=1+"分钟";
	}else if(times>=60 && times<60*60){
		res=parseInt(times/60+1)+"分钟";
	}else if(times>=60*60 && times<60*60*24){
		res=parseInt(times/(60*60))+"小时"+parseInt(times%(60*60)/60+1)+"分钟";
	}else if(times>=60*60*24){
		res=parseInt(times/(60*60*24)+1)+"天";
	}
	return res;
}

function beginExam(id){
	forwordHtmlHref(urls.signatureUrl, beginExamUrl, {examId:id},"_blank");
	//window.open(beginExamUrl+"?examId="+id);
}
function toExamInfo(id, isSso){
    data = {
        "userId":userId,
        "examId":id,
        "type":3
    };
    if(isSso == "1"){
    	$.ajax({
    		type : "post",
    		url : urls.getExamToken,
    		data: data,
    		dataType: "json",
    		success : function(data) {
    			if(data==null){return;}
				$.cookie("fzb_"+1000,1);
    			if(data == 1){
					forwordHtmlHref(urls.signatureUrl, urls.initDoneExam, {examId:id},"_blank");
    				//window.open(urls.initDoneExam+"?examId="+id);
    			}else if(data == 2){
    				//已在其他端考试
    				kickOtherClient(id);
    			}
    		}
    	});
    }else{
		$.cookie("fzb_"+1000,1);
		forwordHtmlHref(urls.signatureUrl, urls.initDoneExam, {examId:id},"_blank");
    	//window.open(urls.initDoneExam+"?examId="+id);
    }
}
function toExamHistory(id){
	forwordHtmlHref(urls.signatureUrl, urls.toExamHistory + "/" + id, {path_variable_examId:id},"_blank");
	//window.open(urls.toExamHistory+"/"+id);
}
function kickOtherClient(id){
    $("#userPwd").attr("value","");
    $("#warningMsg").html("");
    $("#userPwd").css("border", "1px solid #e9e9e9");
    $('#checkPwdMsg').modal("show");
    $("#sureToExam").unbind("click").bind("click", function(){
        var userPwd = $("#userPwd").val();
        if (userPwd == null || userPwd.length == 0) {
            $("#warningMsg").html("请先验证登录密码");
            $("#userPwd").css("border", "1px solid #b94a48");
            clearPwdInfo();
            return;
        } else {
            $.ajax({
                url : urls.kickOtherClient,
                type: "post",
                async: false,
                data: {
                    "userId":userId,
                    "password": userPwd,
                    "type":3,
                    "examId" :id
                },
                success: function (data) {
                    if(data==null){
                    	return;
                    }else if (data == 1) {
						forwordHtmlHref(urls.signatureUrl, urls.initDoneExam, {examId:id},"_blank");
                        //window.open(urls.initDoneExam+"?examId="+id);
                    }else if (data == 2) {
                        $("#warningMsg").html("密码错误,请重新输入");
                        $("#userPwd").css("border", "1px solid #b94a48");
                        $("#userPwd").click(function (){
                            clearPwdInfo();
                        });
                        return;
                    }
                    $('#checkPwdMsg').modal("hide");
                }
            });
        }
    });
}

function clearPwdInfo() {
//        $("#userPwd").attr("value","");
    $("#userPwd").css("border", "1px solid #e9e9e9");
}

function readerTrainLabel(id, isTrain){
	var html = "";
	html += '<span class="relative plane-span" onMouseOver="enter('+id+')" onMouseOut="level('+id+')">';
	html += '<i class="fa fa-paper-plane text-lightgray m-l-xs"></i>';
	html += '<div class="test_triangle" id="plane'+id+'">';
	html += '<div class="popup">';
	html += '<span><em></em></span>';
	if(isTrain == 1){
        html += '<div>本场考试来自培训班</div>';
    } else {
        html += '<div>本场考试来自培训</div>';
	}
	html += '</div>';
	html += '</div>';
	html += '</span>';
	return html;
}
function enter(id){
	$("#plane"+id).addClass('on');
}

function level(id){
	$("#plane"+id).removeClass('on');
}
