/**
 * 该方法主要用于ajax请求，返回所查询出来的结果对象
 * 
 * @param url
 *            ajax的url
 * @param qrydata
 *            ajax请求的参数
 * @param asy
 *            ajax请求同步还是异步
 * @param callback
 *            ajax请求回调函数
 * @param arg
 *            ajax请求回调函数的参数,如果想调用ajax请求回来的数据，就直接把参数名定义成data 示例:["a",data,"cc",1]
 */
function ajaxPublic(url, qrydata, asy, callback, arg) {
	$.ajax({
		url : url,
		type : "post",
		async : asy,
		data : qrydata,
		success : function(data) {
			var data = eval("(" + data + ")");
			if (typeof callback == "function")
				doCallback(callback, data);
			else
				return data;
		},
		cache : false,
		error : function(xhr, errorText) {
			return "操作出错！";
		}
	});
}
/**
 * 去除eval
 * 
 * @param url
 * @param qrydata
 * @param asy
 * @param callback
 * @param arg
 */
function ajaxPubEval(url, qrydata, asy, callback, arg) {
	$.ajax({
		url : url,
		type : "post",
		async : asy,
		data : qrydata,
		success : function(data) {
			if (typeof callback == "function")
				doCallback(callback, data);
			else
				return data;
		},
		cache : false,
		error : function(xhr, errorText) {
			return "操作出错！";
		}
	});
}
function doCallback(fn, args) {
	fn.call(this, args);
}

function emp(val) {
	return "null" == val || val == null ? "" : val
}
function datasub(data) {
	return data && data.length > 36 ? data.substr(0, 36) + "..." : data;
}

function checkSpecialCharacter(val){
    var re=/[，\s_'’‘\"”“|\\~#$@%^&*!。;\/<>\?？]/;
    if(re.test(val)){
        return false;
    }
    return true;
}
function alertWrong(content) {
    return $.alert({
        title: "警告！",
        message: content,
        type: "warning",
        ok: function () {
        }
    });
}
$(document).ready(function() {
	//key enter on search div to search; 
	// find search div
	//选择查询条件，enter查询
	$("div.search_div").each(function(i, div) {
		//条件div
		var $div = $(div);
		//查询按钮
		var $btn = $div.find(".query_btn");
		function onKeyEnter(evt) {
			// click to click query_btn
			if (evt.keyCode == 13) {// 如果取到的键值是回车
				$btn.click();
			}
		}
		// add click function for all input
		$div.find("input").keydown(function(evt) {
			onKeyEnter(evt);
		});
		//获取焦点
		$div.find("div.list_down").attr("tabIndex", 0);
		$div.find("div.list_down").each(function(i, listDown) {
			var $lD = $(listDown);
			$lD.find("div.select_block span").change(function(evt) {
				$lD.focus();
			});
			
		});
		$div.find("div.list_down").keydown(function(evt) {
			onKeyEnter(evt);
		});
		//获取焦点
		$div.find("div.select_blocck").attr("tabIndex", 0);
		$div.find("div.select_blocck").each(function(i, listDown) {
			var $lD = $(listDown);
			$lD.find("div.select_blocck span").change(function(evt) {
				alert(1);
				$lD.focus();
			});
			
		});
		$div.find("div.select_blocck").keydown(function(evt) {
			onKeyEnter(evt);
		});
	});
})
